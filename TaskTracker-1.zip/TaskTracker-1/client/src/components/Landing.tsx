import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { setAuthToken } from "@/lib/authHelpers";
import { ChartLine, Lock, Loader2, AlertCircle, CheckCircle } from "lucide-react";

export default function Landing() {
  const [email, setEmail] = useState("");
  const [employeeId, setEmployeeId] = useState("");
  const [loginSuccess, setLoginSuccess] = useState(false);
  const { toast } = useToast();

  const loginMutation = useMutation({
    mutationFn: async (credentials: { email: string; employee_id: string }) => {
      // For now, we'll use the provided token directly since we have it
      // In a real scenario, this would authenticate with Xano and return a token
      const authToken = 'eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIiwiemlwIjoiREVGIn0.fWGcBOScddhTAjrZuSg4t11ji7LzIgHRLPzn0Zs1iunwdtjtGNDLrulsG7gOLO5rllNmqZiXy3OS2DSRCgKefUnJmcM57NPW.T0LS1eFzN_Z1QqCGLTkeRQ.IUz7DhL1cSMm8WKkcAIwoUV6hKLNT33eAni9BdnJAVop0iVX5mtALNRgOnk7HGmSsQvsi4YiAywcWpzHsmKixE8Gp7KtF9HfjSAktv-YPILcKZ7D7GuggCJvl8YEUwJd5fixgnAiyIbtSf1Cz9pr2tq1mNt-w5KM7FB0S5RpRfs.9VwfyAGPryrar0MtjzvQ0OQhc4du4wFe9aSKfpLf_2k';
      
      return { authToken, user: { email: credentials.email, employee_id: credentials.employee_id } };
    },
    onSuccess: (data) => {
      // Store the auth token and user data
      setAuthToken(data.authToken);
      localStorage.setItem("userData", JSON.stringify(data.user));
      
      setLoginSuccess(true);
      
      toast({
        title: "Login Successful",
        description: "Welcome to FinanceFlow!",
      });
      
      // Smooth redirect to dashboard
      setTimeout(() => {
        window.location.href = "/";
      }, 1500);
    },
    onError: (error: Error) => {
      toast({
        title: "Login Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !employeeId) {
      toast({
        title: "Validation Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    loginMutation.mutate({
      email,
      employee_id: employeeId,
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 px-4 sm:px-6 lg:px-8">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto h-16 w-16 bg-primary rounded-full flex items-center justify-center mb-4">
            <ChartLine className="h-8 w-8 text-white" />
          </div>
          <CardTitle className="text-3xl font-bold text-gray-900">FinanceFlow</CardTitle>
          <p className="text-gray-600">Internal Finance Management System</p>
        </CardHeader>
        
        <CardContent>
          {loginSuccess ? (
            <div className="space-y-4 text-center py-8">
              <div className="mx-auto h-16 w-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Login Successful!</h3>
                <p className="text-sm text-gray-600">Welcome to FinanceFlow. Redirecting you to the dashboard...</p>
              </div>
              <div className="flex items-center justify-center">
                <Loader2 className="h-5 w-5 animate-spin text-green-600" />
              </div>
            </div>
          ) : loginMutation.isPending ? (
            <div className="space-y-4">
              {/* Skeleton for email field */}
              <div className="space-y-2">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-10 w-full" />
              </div>

              {/* Skeleton for employee ID field */}
              <div className="space-y-2">
                <Skeleton className="h-4 w-28" />
                <Skeleton className="h-10 w-full" />
              </div>

              {/* Skeleton for button */}
              <Skeleton className="h-12 w-full" />
              
              {/* Skeleton for helper text */}
              <div className="text-center">
                <Skeleton className="h-3 w-48 mx-auto" />
              </div>

              {/* Loading indicator */}
              <div className="flex items-center justify-center p-4">
                <Loader2 className="h-6 w-6 animate-spin text-gray-600" />
                <span className="ml-2 text-sm text-gray-600">Signing you in...</span>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  disabled={loginMutation.isPending}
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="employeeId">Employee ID</Label>
                <Input
                  id="employeeId"
                  type="text"
                  value={employeeId}
                  onChange={(e) => setEmployeeId(e.target.value)}
                  placeholder="Enter your employee ID"
                  disabled={loginMutation.isPending}
                  required
                />
              </div>

              <Button 
                type="submit"
                className="w-full h-12 text-base font-medium"
                size="lg"
                disabled={loginMutation.isPending}
              >
                <Lock className="mr-2 h-5 w-5" />
                Sign In
              </Button>
              
              <div className="text-center">
                <p className="text-xs text-gray-500">Contact an admin to get access</p>
              </div>

              {loginMutation.isError && (
                <div className="flex items-center p-3 bg-red-50 border border-red-200 rounded-lg">
                  <AlertCircle className="h-4 w-4 text-red-600 mr-2" />
                  <p className="text-sm text-red-800">
                    Unable to sign in. Please check your credentials and try again.
                  </p>
                </div>
              )}
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
