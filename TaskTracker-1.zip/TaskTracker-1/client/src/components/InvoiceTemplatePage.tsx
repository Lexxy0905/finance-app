import { useState } from "react";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { 
  FileText, 
  Download,
  Plus,
  Minus,
  Eye
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { downloadInvoicePDF } from "@/lib/pdfGenerator";

// Invoice item schema
const invoiceItemSchema = z.object({
  description: z.string().min(1, "Description is required"),
  price: z.number().min(0, "Price must be positive"),
  quantity: z.number().min(1, "Quantity must be at least 1"),
});

// Main invoice schema
const invoiceTemplateSchema = z.object({
  clientName: z.string().min(1, "Client name is required"),
  clientAddress: z.string().min(1, "Client address is required"),
  items: z.array(invoiceItemSchema).min(1, "At least one item is required"),
  taxRate: z.number().min(0).max(100).default(9),
  stripePaymentLink: z.string().url("Please enter a valid Stripe payment link").optional().or(z.literal("")),
  notes: z.string().optional(),
});

type InvoiceTemplateForm = z.infer<typeof invoiceTemplateSchema>;

export default function InvoiceTemplatePage() {
  const [previewMode, setPreviewMode] = useState(false);
  const { toast } = useToast();

  const form = useForm<InvoiceTemplateForm>({
    resolver: zodResolver(invoiceTemplateSchema),
    defaultValues: {
      clientName: "",
      clientAddress: "",
      items: [{ description: "", price: 0, quantity: 1 }],
      taxRate: 9,
      stripePaymentLink: "",
      notes: "",
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "items"
  });

  const watchedItems = form.watch("items");
  const watchedTaxRate = form.watch("taxRate");

  // Calculate totals
  const subtotal = watchedItems.reduce((sum, item) => {
    return sum + (item.price * item.quantity);
  }, 0);

  const taxAmount = (subtotal * watchedTaxRate) / 100;
  const total = subtotal + taxAmount;

  // Generate invoice number
  const invoiceNumber = `#${Date.now().toString().slice(-6)}`;
  const currentDate = new Date().toLocaleDateString();
  const validUntilDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString();

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const addItem = () => {
    append({ description: "", price: 0, quantity: 1 });
  };

  const removeItem = (index: number) => {
    if (watchedItems.length > 1) {
      remove(index);
    }
  };

  const handleDownloadPDF = async (data: InvoiceTemplateForm) => {
    try {
      const invoiceData = {
        id: invoiceNumber,
        title: "Custom Invoice",
        amount: total,
        created_at: new Date().toISOString(),
        description: data.notes || "",
        status: "pending",
        client: {
          name: data.clientName,
          email: "",
          address: data.clientAddress,
        },
        items: data.items,
        subtotal,
        taxRate: data.taxRate,
        taxAmount,
        stripePaymentLink: data.stripePaymentLink,
      };

      await downloadInvoicePDF(invoiceData);
      
      toast({
        title: "Success",
        description: "Invoice PDF generated successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate PDF",
        variant: "destructive",
      });
    }
  };

  const onSubmit = (data: InvoiceTemplateForm) => {
    handleDownloadPDF(data);
  };

  if (previewMode) {
    const data = form.getValues();
    return (
      <div className="max-w-4xl mx-auto p-6 space-y-6">
        <div className="flex items-center justify-between mb-6">
          <Button 
            variant="outline" 
            onClick={() => setPreviewMode(false)}
          >
            Back to Edit
          </Button>
          <div className="flex gap-2">
            <Button 
              variant="outline"
              onClick={() => handleDownloadPDF(data)}
            >
              <Download className="h-4 w-4 mr-2" />
              Download PDF
            </Button>
          </div>
        </div>

        {/* Invoice Preview */}
        <Card className="max-w-4xl mx-auto bg-white">
          <CardContent className="p-8">
            {/* Header */}
            <div className="text-center mb-8">
              <h1 className="text-sm text-gray-600 tracking-wide uppercase mb-2">
                Architecture Analysis & Oversight
              </h1>
              <h2 className="text-6xl font-light tracking-wider text-black">
                Quotation
              </h2>
            </div>

            {/* Invoice Details */}
            <div className="flex justify-between items-start mb-8 border-b border-gray-300 pb-4">
              <div className="space-y-1">
                <div className="text-sm">
                  <span className="font-medium">Date:</span> {currentDate}
                </div>
                <div className="text-sm">
                  <span className="font-medium">Valid Until Date:</span> {validUntilDate}
                </div>
              </div>
              <div className="text-sm">
                <span className="font-medium">Invoice Number:</span> {invoiceNumber}
              </div>
            </div>

            {/* Client Info */}
            <div className="flex justify-between mb-8 border-b border-gray-300 pb-4">
              <div>
                <div className="text-sm">
                  <span className="font-medium">To:</span> {data.clientName}
                </div>
              </div>
              <div className="text-right text-sm">
                <div>{data.clientAddress}</div>
              </div>
            </div>

            {/* Items Table */}
            <div className="mb-8">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-300">
                    <th className="text-left py-3 font-medium">Item Description</th>
                    <th className="text-right py-3 font-medium">Price</th>
                    <th className="text-right py-3 font-medium">QTY</th>
                    <th className="text-right py-3 font-medium">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {data.items.map((item, index) => (
                    <tr key={index} className="border-b border-gray-100">
                      <td className="py-4">{item.description}</td>
                      <td className="text-right py-4">{formatCurrency(item.price)}</td>
                      <td className="text-right py-4">{item.quantity}</td>
                      <td className="text-right py-4">{formatCurrency(item.price * item.quantity)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Totals */}
            <div className="flex justify-end mb-8">
              <div className="w-64 space-y-2">
                <div className="flex justify-between border-b border-gray-300 pb-2">
                  <span>Subtotal :</span>
                  <span>{formatCurrency(subtotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Tax ({data.taxRate}%) :</span>
                  <span>{formatCurrency(taxAmount)}</span>
                </div>
                <div className="flex justify-between font-bold text-lg border-t border-gray-300 pt-2">
                  <span>Total Due :</span>
                  <span>{formatCurrency(total)}</span>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="flex justify-between items-end">
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 bg-gray-800 flex items-center justify-center">
                  <div className="text-white font-bold text-xl">D</div>
                </div>
                <div>
                  <div className="font-medium text-lg">Designhaus</div>
                  <div className="font-medium text-lg">Architecture</div>
                  <div className="font-medium text-lg">& Design</div>
                </div>
              </div>
              <div className="text-right text-sm">
                <div>123 Creative Lane</div>
                <div>New York, NY 10001</div>
                <div>(123) 456-7890</div>
                <div>www.example.com</div>
              </div>
            </div>

            {/* Payment Link */}
            {data.stripePaymentLink && (
              <div className="mt-8 p-4 bg-blue-50 rounded-lg border-2 border-blue-200">
                <div className="text-center">
                  <p className="text-sm text-gray-600 mb-2">Pay Online:</p>
                  <a 
                    href={data.stripePaymentLink} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-block bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    Pay Now with Stripe
                  </a>
                </div>
              </div>
            )}

            {/* Notes */}
            {data.notes && (
              <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                <h4 className="font-medium mb-2">Notes:</h4>
                <p className="text-sm text-gray-600">{data.notes}</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Invoice Template</h2>
          <p className="text-gray-600">Create professional invoices with PDF generation</p>
        </div>
        <Button 
          variant="outline"
          onClick={() => setPreviewMode(true)}
          disabled={!form.formState.isValid}
        >
          <Eye className="h-4 w-4 mr-2" />
          Preview
        </Button>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* Client Information */}
          <Card>
            <CardHeader>
              <CardTitle>Client Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="clientName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Client Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Johnny & Betty Gibbins" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="clientAddress"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Client Address</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="321 Rodeo Dr&#10;Old Rochelle, NY 90210" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {/* Invoice Items */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Invoice Items</CardTitle>
                <Button type="button" variant="outline" size="sm" onClick={addItem}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Item
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {watchedItems.map((_, index) => (
                <div key={index} className="grid grid-cols-12 gap-4 items-end p-4 border rounded-lg">
                  <div className="col-span-5">
                    <FormField
                      control={form.control}
                      name={`items.${index}.description`}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Input placeholder="Architectural design" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <div className="col-span-3">
                    <FormField
                      control={form.control}
                      name={`items.${index}.price`}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Price</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              step="0.01"
                              placeholder="2000" 
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <div className="col-span-2">
                    <FormField
                      control={form.control}
                      name={`items.${index}.quantity`}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Qty</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              min="1"
                              placeholder="1" 
                              {...field}
                              onChange={(e) => field.onChange(parseInt(e.target.value) || 1)}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <div className="col-span-2 flex items-center justify-between">
                    <div className="text-right">
                      <Label className="text-sm text-gray-500">Amount</Label>
                      <div className="font-medium">
                        {formatCurrency((watchedItems[index]?.price || 0) * (watchedItems[index]?.quantity || 1))}
                      </div>
                    </div>
                    {watchedItems.length > 1 && (
                      <Button 
                        type="button" 
                        variant="ghost" 
                        size="sm"
                        onClick={() => removeItem(index)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <Minus className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
              ))}

              {/* Totals Display */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex justify-end">
                  <div className="w-64 space-y-2">
                    <div className="flex justify-between">
                      <span>Subtotal:</span>
                      <span>{formatCurrency(subtotal)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Tax ({watchedTaxRate}%):</span>
                      <span>{formatCurrency(taxAmount)}</span>
                    </div>
                    <div className="flex justify-between font-bold text-lg border-t pt-2">
                      <span>Total:</span>
                      <span>{formatCurrency(total)}</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Settings */}
          <Card>
            <CardHeader>
              <CardTitle>Invoice Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="taxRate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tax Rate (%)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        step="0.1"
                        min="0"
                        max="100"
                        placeholder="9" 
                        {...field}
                        onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="stripePaymentLink"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Stripe Payment Link (Optional)</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="https://buy.stripe.com/..." 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes (Optional)</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Additional notes or payment terms..." 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="flex justify-end space-x-3">
            <Button type="button" variant="outline" onClick={() => setPreviewMode(true)}>
              <Eye className="h-4 w-4 mr-2" />
              Preview
            </Button>
            <Button type="submit">
              <Download className="h-4 w-4 mr-2" />
              Generate PDF
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}