import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { 
  CreditCard, 
  DollarSign, 
  Calendar,
  User,
  AlertCircle,
  CheckCircle,
  Loader2
} from "lucide-react";

interface PaymentModalProps {
  open: boolean;
  onClose: () => void;
  invoice?: any;
}

export default function PaymentModal({ open, onClose, invoice }: PaymentModalProps) {
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createPaymentIntentMutation = useMutation({
    mutationFn: async ({ amount, invoiceId }: { amount: string; invoiceId: number }) => {
      const response = await apiRequest("POST", "/api/create-payment-intent", {
        amount,
        invoiceId,
      });
      return response.json();
    },
    onSuccess: (data) => {
      // In a real implementation, this would redirect to Stripe Checkout
      // For now, we'll simulate the payment process
      setIsProcessing(true);
      
      // Simulate payment processing
      setTimeout(() => {
        setIsProcessing(false);
        
        // Simulate successful payment
        toast({
          title: "Payment Successful",
          description: "The invoice has been paid successfully via Stripe.",
        });
        
        // Invalidate queries to refresh data
        queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
        queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
        
        onClose();
      }, 3000);
    },
    onError: (error: Error) => {
      setIsProcessing(false);
      
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      
      toast({
        title: "Payment Failed",
        description: "Failed to process payment. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handlePayment = () => {
    if (!invoice) return;
    
    createPaymentIntentMutation.mutate({
      amount: invoice.amount,
      invoiceId: invoice.id,
    });
  };

  const formatCurrency = (amount: string | number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(typeof amount === 'string' ? parseFloat(amount) : amount);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  if (!invoice) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <CreditCard className="mr-2 h-5 w-5" />
            Process Payment
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Invoice Details */}
          <Card>
            <CardContent className="p-4 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Invoice ID</span>
                <span className="font-medium text-blue-600">
                  #INV-{String(invoice.id).padStart(4, '0')}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Employee</span>
                <span className="font-medium text-gray-900">
                  {/* This would be populated from employee data in real implementation */}
                  Employee
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Due Date</span>
                <span className="font-medium text-gray-900">
                  {formatDate(invoice.dueDate)}
                </span>
              </div>
              
              {invoice.description && (
                <div className="pt-2 border-t">
                  <span className="text-sm text-gray-600">Description</span>
                  <p className="text-sm text-gray-900 mt-1">{invoice.description}</p>
                </div>
              )}
              
              <div className="flex items-center justify-between pt-2 border-t">
                <span className="text-lg font-semibold text-gray-900">Total Amount</span>
                <span className="text-2xl font-bold text-green-600">
                  {formatCurrency(invoice.amount)}
                </span>
              </div>
            </CardContent>
          </Card>

          {/* Payment Status */}
          {isProcessing ? (
            <Card>
              <CardContent className="p-6 text-center">
                <div className="flex flex-col items-center space-y-3">
                  <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
                  <h3 className="font-medium text-gray-900">Processing Payment</h3>
                  <p className="text-sm text-gray-600">
                    Please wait while we process your payment via Stripe...
                  </p>
                  <div className="w-full bg-gray-200 rounded-full h-2 mt-4">
                    <div className="bg-blue-600 h-2 rounded-full animate-pulse" style={{ width: '70%' }} />
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : (
            <>
              {/* Payment Method */}
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <div className="flex-shrink-0">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <CreditCard className="h-5 w-5 text-blue-600" />
                      </div>
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-900">Stripe Payment</h3>
                      <p className="text-sm text-gray-600">
                        Secure payment processing via Stripe
                      </p>
                    </div>
                    <Badge variant="secondary" className="bg-green-100 text-green-800">
                      Secure
                    </Badge>
                  </div>
                </CardContent>
              </Card>

              {/* Warning Notice */}
              <div className="flex items-start space-x-3 p-4 bg-amber-50 border border-amber-200 rounded-lg">
                <AlertCircle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm">
                  <p className="font-medium text-amber-800">Payment Confirmation</p>
                  <p className="text-amber-700 mt-1">
                    This will process a payment of {formatCurrency(invoice.amount)} to the employee. 
                    This action cannot be undone.
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex space-x-3">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={onClose}
                  className="flex-1"
                  disabled={createPaymentIntentMutation.isPending}
                >
                  Cancel
                </Button>
                <Button 
                  onClick={handlePayment}
                  disabled={createPaymentIntentMutation.isPending}
                  className="flex-1 bg-green-600 hover:bg-green-700"
                >
                  {createPaymentIntentMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <CreditCard className="mr-2 h-4 w-4" />
                      Pay {formatCurrency(invoice.amount)}
                    </>
                  )}
                </Button>
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
