import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import {
  ChartLine,
  Home,
  Users,
  UserRoundCheck,
  FileText,
  Receipt,
  DollarSign,
  Plus,
  Bell,
  LogOut,
  Menu,
  X,
  PenTool
} from "lucide-react";


interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const [sidebarOpen, setSidebarOpen] = useState(false);


  const handleLogout = () => {
    localStorage.removeItem("authToken");
    localStorage.removeItem("userData");
    
    toast({
      title: "Signed out",
      description: "You have been logged out successfully.",
    });
    
    setTimeout(() => {
      window.location.href = "/login";
    }, 1000);
  };

  const navItems = [
    { path: "/", icon: Home, label: "Dashboard" },
    { path: "/clients", icon: Users, label: "Clients" },
    { path: "/employees", icon: UserRoundCheck, label: "Employees" },
    { path: "/client-invoices", icon: DollarSign, label: "Client Invoices" },
    { path: "/employee-invoices", icon: Receipt, label: "Employee Invoices" },
    { path: "/quotation-template", icon: PenTool, label: "Quotation Template" },
  ];

  const getPageTitle = () => {
    switch (location) {
      case "/clients": return "Clients";
      case "/employees": return "Employees";
      case "/client-invoices": return "Client Invoices";
      case "/employee-invoices": return "Employee Invoices";
      case "/quotation-template": return "Quotation Template";
      default: return "Dashboard";
    }
  };

  const getPageSubtitle = () => {
    switch (location) {
      case "/clients": return "Manage your client relationships and invoicing";
      case "/employees": return "Manage employee information and payments";
      case "/client-invoices": return "Manage and track client billing";
      case "/employee-invoices": return "Review and approve employee invoice submissions";
      case "/quotation-template": return "Create professional quotations with PDF generation";
      default: return "Welcome back! Here's your finance overview.";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile sidebar backdrop */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-gray-600 bg-opacity-50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={`fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-lg border-r border-gray-200 transform ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 transition-transform duration-300 ease-in-out flex flex-col`}>
        {/* Logo Header */}
        <div className="flex items-center px-6 py-4 border-b border-gray-200">
          <div className="h-8 w-8 bg-primary rounded-lg flex items-center justify-center mr-3">
            <ChartLine className="h-5 w-5 text-white" />
          </div>
          <h1 className="text-xl font-semibold text-gray-900">FinanceFlow</h1>
          <Button
            variant="ghost"
            size="sm"
            className="ml-auto lg:hidden"
            onClick={() => setSidebarOpen(false)}
          >
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        {/* Navigation Menu */}
        <nav className="flex-1 px-4 py-6 space-y-2">
          {navItems.map((item) => {
            const isActive = location === item.path;
            return (
              <Link key={item.path} href={item.path}>
                <Button
                  variant={isActive ? "default" : "ghost"}
                  className={`w-full justify-start ${isActive ? 'bg-primary text-white' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'}`}
                  onClick={() => setSidebarOpen(false)}
                >
                  <item.icon className="mr-3 h-5 w-5" />
                  {item.label}
                </Button>
              </Link>
            );
          })}
        </nav>
        
        {/* User Profile - Fixed at bottom */}
        <div className="px-4 py-4 border-t border-gray-200 mt-auto">
          <div className="flex items-center">
            <div className="h-8 w-8 bg-gray-300 rounded-full flex items-center justify-center">
              <span className="text-gray-600 text-sm font-medium">
                {(() => {
                  const userData = localStorage.getItem("userData");
                  if (userData) {
                    const user = JSON.parse(userData);
                    return user?.email?.[0]?.toUpperCase() || 'A';
                  }
                  return 'A';
                })()}
              </span>
            </div>
            <div className="ml-3 flex-1">
              <p className="text-sm font-medium text-gray-900">
                {(() => {
                  const userData = localStorage.getItem("userData");
                  if (userData) {
                    const user = JSON.parse(userData);
                    return user?.email || 'Admin User';
                  }
                  return 'Admin User';
                })()}
              </p>
              <p className="text-xs text-gray-500">Administrator</p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLogout}
              className="text-gray-400 hover:text-gray-600"
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="lg:pl-64 min-h-screen">
        {/* Top Header */}
        <header className="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Button
                variant="ghost"
                size="sm"
                className="lg:hidden mr-4"
                onClick={() => setSidebarOpen(true)}
              >
                <Menu className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-semibold text-gray-900">{getPageTitle()}</h1>
                <p className="text-gray-600 text-sm">{getPageSubtitle()}</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Button variant="ghost" size="sm" className="relative">
                  <Bell className="h-5 w-5" />
                  <span className="absolute top-0 right-0 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center -mt-1 -mr-1">
                    3
                  </span>
                </Button>
              </div>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 p-6">
          {children}
        </main>
      </div>


    </div>
  );
}
