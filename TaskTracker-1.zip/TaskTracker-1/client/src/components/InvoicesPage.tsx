import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { getAuthToken } from "@/lib/authHelpers";
import {
  FileText,
  Search,
  Download,
  Eye,
  Edit,
  Check,
  CreditCard,
  Filter
} from "lucide-react";
import PaymentModal from "./PaymentModal";

export default function InvoicesPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");

  const [paymentModal, setPaymentModal] = useState<{ open: boolean; invoice?: any }>({ open: false });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: invoices, isLoading } = useQuery({
    queryKey: ["/api/invoices"],
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
    },
  });

  const { data: clients } = useQuery({
    queryKey: ["/api/clients"],
  });

  const { data: employees } = useQuery({
    queryKey: ["employees"],
    queryFn: async () => {
      const authToken = getAuthToken();
      if (!authToken) {
        throw new Error("No authentication token");
      }
      
      const response = await fetch('https://x8ki-letl-twmt.n7.xano.io/api:CUU7m57L/user', {
        headers: {
          'Authorization': authToken,
          'Content-Type': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch employees');
      }
      
      const data = await response.json();
      // Return the user array from Xano response
      return data.user || [];
    },
    enabled: !!getAuthToken()
  });

  const markAsPaidMutation = useMutation({
    mutationFn: async (invoiceId: number) => {
      const response = await apiRequest("PUT", `/api/invoices/${invoiceId}`, {
        status: "paid"
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Success",
        description: "Invoice marked as paid",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update invoice",
        variant: "destructive",
      });
    },
  });

  const getRecipientName = (invoice: any) => {
    if (invoice.clientId) {
      return clients?.find((c: any) => c.id === invoice.clientId)?.name || "Unknown Client";
    }
    if (invoice.employeeId) {
      return employees?.find((e: any) => e.id === invoice.employeeId)?.name || "Unknown Employee";
    }
    return "Unknown";
  };

  const getRecipientEmail = (invoice: any) => {
    if (invoice.clientId) {
      return clients?.find((c: any) => c.id === invoice.clientId)?.email || "";
    }
    if (invoice.employeeId) {
      return employees?.find((e: any) => e.id === invoice.employeeId)?.email || "";
    }
    return "";
  };

  const formatCurrency = (amount: string | number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(typeof amount === 'string' ? parseFloat(amount) : amount);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const isOverdue = (dueDate: string) => {
    return new Date(dueDate) < new Date();
  };

  const getStatusBadgeColor = (status: string, dueDate: string) => {
    if (status === "paid") return "default";
    if (isOverdue(dueDate)) return "destructive";
    return "secondary";
  };

  const getStatusText = (status: string, dueDate: string) => {
    if (status === "paid") return "Paid";
    if (isOverdue(dueDate)) return "Overdue";
    return "Pending";
  };

  const filteredInvoices = invoices?.filter((invoice: any) => {
    const matchesSearch = 
      getRecipientName(invoice).toLowerCase().includes(searchTerm.toLowerCase()) ||
      invoice.id.toString().includes(searchTerm) ||
      invoice.amount.toString().includes(searchTerm);
    
    const matchesStatus = statusFilter === "all" || 
      (statusFilter === "paid" && invoice.status === "paid") ||
      (statusFilter === "unpaid" && invoice.status === "unpaid") ||
      (statusFilter === "overdue" && invoice.status === "unpaid" && isOverdue(invoice.dueDate));
    
    const matchesType = typeFilter === "all" ||
      (typeFilter === "client" && invoice.clientId) ||
      (typeFilter === "employee" && invoice.employeeId);
    
    return matchesSearch && matchesStatus && matchesType;
  }) || [];

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse bg-gray-200 rounded h-8 w-64" />
        <div className="animate-pulse bg-gray-200 rounded-lg h-32" />
        <div className="animate-pulse bg-gray-200 rounded-lg h-96" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Invoices</h2>
          <p className="text-gray-600">View and manage all invoices</p>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search invoices..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="paid">Paid</SelectItem>
                <SelectItem value="unpaid">Unpaid</SelectItem>
                <SelectItem value="overdue">Overdue</SelectItem>
              </SelectContent>
            </Select>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="client">Client Invoices</SelectItem>
                <SelectItem value="employee">Employee Invoices</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline">
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Invoices Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>All Invoices</CardTitle>
            <div className="text-sm text-gray-500">
              {filteredInvoices.length} invoice{filteredInvoices.length !== 1 ? 's' : ''} found
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {filteredInvoices.length === 0 ? (
            <div className="text-center py-12">
              <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No invoices found</h3>
              <p className="text-gray-500 mb-4">
                {searchTerm || statusFilter !== "all" || typeFilter !== "all" 
                  ? "No invoices match your current filters." 
                  : "No invoices found. Create invoices from the Client Invoices section."
                }
              </p>

            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-4 font-medium text-gray-700">Invoice ID</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-700">Recipient</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-700">Type</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-700">Amount</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-700">Due Date</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-700">Status</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-700">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredInvoices.map((invoice: any) => (
                    <tr key={invoice.id} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="py-3 px-4">
                        <div>
                          <div className="font-medium text-blue-600">
                            #INV-{String(invoice.id).padStart(4, '0')}
                          </div>
                          <div className="text-sm text-gray-500">
                            {formatDate(invoice.createdAt)}
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <div>
                          <div className="font-medium text-gray-900">{getRecipientName(invoice)}</div>
                          <div className="text-sm text-gray-500">{getRecipientEmail(invoice)}</div>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <Badge 
                          variant={invoice.clientId ? "default" : "secondary"}
                          className={invoice.clientId ? "bg-blue-100 text-blue-800" : "bg-green-100 text-green-800"}
                        >
                          {invoice.clientId ? "Client" : "Employee"}
                        </Badge>
                      </td>
                      <td className="py-3 px-4 font-semibold text-gray-900">
                        {formatCurrency(invoice.amount)}
                      </td>
                      <td className="py-3 px-4 text-gray-900">
                        {formatDate(invoice.dueDate)}
                      </td>
                      <td className="py-3 px-4">
                        <Badge variant={getStatusBadgeColor(invoice.status, invoice.dueDate)}>
                          {getStatusText(invoice.status, invoice.dueDate)}
                        </Badge>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex space-x-2">
                          <Button variant="ghost" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Download className="h-4 w-4" />
                          </Button>
                          {invoice.status === "unpaid" && (
                            <>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => markAsPaidMutation.mutate(invoice.id)}
                                disabled={markAsPaidMutation.isPending}
                              >
                                <Check className="h-4 w-4" />
                              </Button>
                              {invoice.employeeId && (
                                <Button 
                                  size="sm"
                                  onClick={() => setPaymentModal({ open: true, invoice })}
                                  className="bg-green-600 hover:bg-green-700"
                                >
                                  <CreditCard className="h-4 w-4" />
                                </Button>
                              )}
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>



      {/* Payment Modal */}
      <PaymentModal 
        open={paymentModal.open}
        onClose={() => setPaymentModal({ open: false })}
        invoice={paymentModal.invoice}
      />
    </div>
  );
}
