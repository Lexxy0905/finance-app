import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X } from "lucide-react";
import { getAuthToken } from "@/lib/authHelpers";
import { useToast } from "@/hooks/use-toast";

interface EmployeeInvoiceDetailsModalProps {
  open: boolean;
  onClose: () => void;
  employeeInvoiceId?: number;
}

export default function EmployeeInvoiceDetailsModal({
  open,
  onClose,
  employeeInvoiceId
}: EmployeeInvoiceDetailsModalProps) {
  const [selectedStatus, setSelectedStatus] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch employee invoice details
  const { data: invoiceDetails, isLoading } = useQuery({
    queryKey: ["employee-invoice", employeeInvoiceId],
    queryFn: async () => {
      if (!employeeInvoiceId) return null;
      
      const authToken = getAuthToken();
      if (!authToken) {
        throw new Error("No authentication token");
      }
      
      const response = await fetch(
        `https://x8ki-letl-twmt.n7.xano.io/api:CUU7m57L/employee_invoice/${employeeInvoiceId}`,
        {
          headers: {
            'Authorization': authToken,
            'Content-Type': 'application/json'
          }
        }
      );
      
      if (!response.ok) {
        throw new Error('Failed to fetch invoice details');
      }
      
      return response.json();
    },
    enabled: !!employeeInvoiceId && open
  });

  // Update invoice status mutation
  const updateStatusMutation = useMutation({
    mutationFn: async ({ status }: { status: string }) => {
      if (!employeeInvoiceId) throw new Error("No invoice ID");
      
      const authToken = getAuthToken();
      if (!authToken) {
        throw new Error("No authentication token");
      }
      
      const response = await fetch(
        `https://x8ki-letl-twmt.n7.xano.io/api:CUU7m57L/employee_invoice/${employeeInvoiceId}`,
        {
          method: 'PATCH',
          headers: {
            'Authorization': authToken,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ status })
        }
      );
      
      if (!response.ok) {
        throw new Error('Failed to update invoice status');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["employee-invoice", employeeInvoiceId] });
      queryClient.invalidateQueries({ queryKey: ["employee-invoices"] });
      toast({
        title: "Success",
        description: "Invoice status updated successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to update status: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const handleStatusChange = () => {
    if (!selectedStatus) return;
    updateStatusMutation.mutate({ status: selectedStatus });
  };

  const formatCurrency = (amount: string | number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(typeof amount === 'string' ? parseFloat(amount) : amount);
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'paid':
        return 'default';
      case 'pending':
        return 'secondary';
      case 'cancelled':
        return 'destructive';
      default:
        return 'secondary';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'paid':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (!open) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md mx-auto">
        <DialogHeader className="flex flex-row items-center justify-between">
          <DialogTitle className="text-lg font-semibold text-gray-900">
            Invoice Details
          </DialogTitle>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={onClose}
            className="h-8 w-8 p-0"
          >
            <X className="h-4 w-4" />
          </Button>
        </DialogHeader>
        
        {isLoading ? (
          <div className="space-y-4 p-6">
            <div className="animate-pulse bg-gray-200 rounded h-6 w-32" />
            <div className="animate-pulse bg-gray-200 rounded h-4 w-24" />
            <div className="space-y-3">
              {Array(5).fill(0).map((_, i) => (
                <div key={i} className="animate-pulse bg-gray-200 rounded h-4 w-full" />
              ))}
            </div>
          </div>
        ) : invoiceDetails ? (
          <div className="space-y-6 p-6">
            {/* Invoice Header */}
            <div className="text-center">
              <div className="inline-block bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium mb-2">
                Invoice Block 14
              </div>
              <div className="text-lg font-semibold text-gray-600">
                #{invoiceDetails.id || '023393'}
              </div>
            </div>

            {/* Invoice Details */}
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-700">Employee Name:</label>
                <div className="text-gray-900 mt-1">{invoiceDetails.employee_name || 'Seun Grilly'}</div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700">Invoice Title:</label>
                <div className="text-gray-900 mt-1">{invoiceDetails.title || 'Invoice for New Landing Page'}</div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700">Total Hours:</label>
                <div className="text-gray-900 mt-1">{invoiceDetails.hours || '-'}</div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700">Total Amount:</label>
                <div className="text-gray-900 mt-1 font-semibold">
                  {formatCurrency(invoiceDetails.amount || invoiceDetails.total_amount || 1500)}
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700">Description:</label>
                <div className="text-gray-900 mt-1">
                  {invoiceDetails.description || 'Lorem eheuh efohj divebwbiv ev. dovinjov ovjioj'}
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700">Status:</label>
                <div className="mt-1">
                  <Badge 
                    variant={getStatusBadgeVariant(invoiceDetails.status)}
                    className={getStatusColor(invoiceDetails.status)}
                  >
                    {(invoiceDetails.status || 'Paid').charAt(0).toUpperCase() + (invoiceDetails.status || 'Paid').slice(1)}
                  </Badge>
                </div>
              </div>

              {/* Change Status Section */}
              <div className="pt-4 border-t">
                <label className="text-sm font-medium text-gray-700 mb-2 block">
                  Change Status <span className="text-gray-500">(Mark as PAID or REJECT):</span>
                </label>
                <div className="flex gap-3">
                  <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                    <SelectTrigger className="flex-1">
                      <SelectValue placeholder="Select Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="paid">Paid</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button 
                    onClick={handleStatusChange}
                    disabled={!selectedStatus || updateStatusMutation.isPending}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    {updateStatusMutation.isPending ? "Updating..." : "Change"}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="p-6 text-center text-gray-500">
            Failed to load invoice details
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}