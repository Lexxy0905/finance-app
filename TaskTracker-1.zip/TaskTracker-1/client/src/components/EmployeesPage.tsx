import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { getAuthToken } from "@/lib/authHelpers";
import {
  UserRoundCheck,
  Plus,
  Search,
  Eye,
  Edit,
  Trash2,
  FileText,
  Mail,
  Phone,
  CreditCard,
  Crown,
  UserX
} from "lucide-react";
import PaymentModal from "./PaymentModal";

const employeeSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Invalid email address"),
  fields_id: z.string().min(1, "Field is required"),
  acct_details: z.string().min(1, "Account details are required"),
  rate: z.string().min(1, "Rate is required"),
});

type EmployeeFormData = z.infer<typeof employeeSchema>;

export default function EmployeesPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<any>(null);
  const [paymentModal, setPaymentModal] = useState<{ open: boolean; invoice?: any }>({ open: false });
  const [adminConfirmDialog, setAdminConfirmDialog] = useState<{ open: boolean; employee?: any }>({ open: false });
  const [deleteConfirmDialog, setDeleteConfirmDialog] = useState<{ open: boolean; employee?: any }>({ open: false });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<EmployeeFormData>({
    resolver: zodResolver(employeeSchema),
    defaultValues: {
      name: "",
      email: "",
      fields_id: "",
      acct_details: "",
      rate: "",
    },
  });

  const { data: employees, isLoading } = useQuery({
    queryKey: ["employees"],
    queryFn: async () => {
      const authToken = getAuthToken();
      if (!authToken) {
        throw new Error("No authentication token");
      }
      
      const response = await fetch('https://x8ki-letl-twmt.n7.xano.io/api:CUU7m57L/user', {
        headers: {
          'Authorization': authToken,
          'Content-Type': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch employees');
      }
      
      const data = await response.json();
      // Return the user array from Xano response
      return data.user || [];
    },
    enabled: !!getAuthToken()
  });

  // Note: Invoices would need to be fetched from Xano as well if needed
  const invoices: any[] = [];

  // Fetch fields from Xano
  const { data: fields } = useQuery({
    queryKey: ["fields"],
    queryFn: async () => {
      const authToken = getAuthToken();
      if (!authToken) {
        throw new Error("No authentication token");
      }
      
      const response = await fetch('https://x8ki-letl-twmt.n7.xano.io/api:CUU7m57L/fields', {
        headers: {
          'Authorization': authToken,
          'Content-Type': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch fields');
      }
      
      return response.json();
    },
    enabled: !!getAuthToken()
  });

  const createEmployeeMutation = useMutation({
    mutationFn: async (data: EmployeeFormData) => {
      const authToken = getAuthToken();
      if (!authToken) {
        throw new Error("No authentication token");
      }
      
      const response = await fetch('https://x8ki-letl-twmt.n7.xano.io/api:CUU7m57L/user', {
        method: 'POST',
        headers: {
          'Authorization': authToken,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
      });
      
      if (!response.ok) {
        throw new Error('Failed to create employee');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["employees"] });
      toast({
        title: "Success",
        description: "Employee created successfully",
      });
      setShowAddModal(false);
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create employee",
        variant: "destructive",
      });
    },
  });

  // Update and delete functionality would need Xano endpoints
  const updateEmployeeMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: EmployeeFormData }) => {
      // This would need a Xano update endpoint
      throw new Error("Update functionality not implemented yet");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["employees"] });
      toast({
        title: "Success",
        description: "Employee updated successfully",
      });
      setEditingEmployee(null);
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: "Update functionality not available yet",
        variant: "destructive",
      });
    },
  });

  const deleteEmployeeMutation = useMutation({
    mutationFn: async (id: number) => {
      // This would need a Xano delete endpoint
      throw new Error("Delete functionality not implemented yet");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["employees"] });
      toast({
        title: "Success",
        description: "Employee deleted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: "Delete functionality not available yet",
        variant: "destructive",
      });
    },
  });

  const makeAdminMutation = useMutation({
    mutationFn: async (userId: number) => {
      const authToken = getAuthToken();
      if (!authToken) {
        throw new Error("No authentication token");
      }
      
      const response = await fetch(`https://x8ki-letl-twmt.n7.xano.io/api:CUU7m57L/user/${userId}`, {
        method: 'PATCH',
        headers: {
          'Authorization': authToken,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          role: 'admin'
        })
      });
      
      if (!response.ok) {
        throw new Error('Failed to make user admin');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["employees"] });
      toast({
        title: "Success",
        description: "User has been made an admin successfully",
      });
      setAdminConfirmDialog({ open: false });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to make user admin",
        variant: "destructive",
      });
      setAdminConfirmDialog({ open: false });
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (userId: number) => {
      const authToken = getAuthToken();
      if (!authToken) {
        throw new Error("No authentication token");
      }
      
      const response = await fetch(`https://x8ki-letl-twmt.n7.xano.io/api:CUU7m57L/user/${userId}/delete`, {
        method: 'PATCH',
        headers: {
          'Authorization': authToken,
          'Content-Type': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to delete user');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["employees"] });
      toast({
        title: "Success",
        description: "Employee has been deleted successfully",
      });
      setDeleteConfirmDialog({ open: false });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete employee",
        variant: "destructive",
      });
      setDeleteConfirmDialog({ open: false });
    },
  });

  const onSubmit = (data: EmployeeFormData) => {
    if (editingEmployee) {
      updateEmployeeMutation.mutate({ id: editingEmployee.id, data });
    } else {
      createEmployeeMutation.mutate(data);
    }
  };

  const handleEdit = (employee: any) => {
    setEditingEmployee(employee);
    form.reset({
      name: employee.name,
      email: employee.email,
      fields_id: employee.fields_id?.toString() || "",
      acct_details: employee.acct_details || "",
      rate: employee.rate || "",
    });
  };

  const handleDelete = (employee: any) => {
    if (confirm(`Are you sure you want to delete ${employee.name}?`)) {
      deleteEmployeeMutation.mutate(employee.id);
    }
  };

  const handleToggleAdmin = (employee: any) => {
    // Only allow making users admin, not removing admin privileges
    if (employee.role !== 'admin') {
      setAdminConfirmDialog({ open: true, employee });
    }
  };

  const handleDeleteUser = (employee: any) => {
    setDeleteConfirmDialog({ open: true, employee });
  };

  const getEmployeeInvoices = (employeeId: number) => {
    if (!invoices) return [];
    return invoices.filter((inv: any) => inv.employeeId === employeeId);
  };

  const getUnpaidAmount = (employeeId: number) => {
    const employeeInvoices = getEmployeeInvoices(employeeId);
    const unpaidInvoices = employeeInvoices.filter((inv: any) => inv.status === "unpaid");
    return unpaidInvoices.reduce((sum: number, inv: any) => sum + parseFloat(inv.amount), 0);
  };

  const pendingPayments = invoices?.filter((inv: any) => 
    inv.status === "unpaid" && inv.employeeId
  ) || [];

  const employeesList = Array.isArray(employees) ? employees : [];
  const filteredEmployees = employeesList.filter((employee: any) =>
    employee.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    employee.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (employee.role && employee.role.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const getRoleColor = (role: string) => {
    const colors: { [key: string]: string } = {
      developer: "bg-blue-100 text-blue-800",
      designer: "bg-purple-100 text-purple-800",
      consultant: "bg-green-100 text-green-800",
      manager: "bg-orange-100 text-orange-800",
    };
    return colors[role.toLowerCase()] || "bg-gray-100 text-gray-800";
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse bg-gray-200 rounded h-8 w-64" />
        <div className="animate-pulse bg-gray-200 rounded-lg h-48" />
        <div className="overflow-x-auto">
          <div className="animate-pulse bg-gray-200 rounded-lg h-96" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Employees</h2>
          <p className="text-gray-600">Manage employee information and payments</p>
        </div>
        <Dialog open={showAddModal || !!editingEmployee} onOpenChange={(open) => {
          if (!open) {
            setShowAddModal(false);
            setEditingEmployee(null);
            form.reset();
          }
        }}>
          <DialogTrigger asChild>
            <Button onClick={() => setShowAddModal(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Add Employee
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingEmployee ? "Edit Employee" : "Add New Employee"}
              </DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Employee name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input type="email" placeholder="employee@example.com" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="fields_id"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Department</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select department" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {fields?.map((fieldItem: any) => (
                            <SelectItem key={fieldItem.id} value={fieldItem.id.toString()}>
                              {fieldItem.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="rate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Hourly Rate</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="$ Hourly Rate" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="acct_details"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Account Details</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Account Details"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="flex justify-end space-x-2">
                  <Button 
                    type="button" 
                    variant="outline"
                    onClick={() => {
                      setShowAddModal(false);
                      setEditingEmployee(null);
                      form.reset();
                    }}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={createEmployeeMutation.isPending || updateEmployeeMutation.isPending}
                  >
                    {editingEmployee ? "Update" : "Create"} Employee
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Pending Payments Summary */}
      {pendingPayments.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <CreditCard className="mr-2 h-5 w-5" />
              Pending Employee Payments
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {pendingPayments.map((invoice: any) => {
                const employee = employees?.find((e: any) => e.id === invoice.employeeId);
                return (
                  <div key={invoice.id} className="flex items-center justify-between p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-gray-300 rounded-full flex items-center justify-center mr-3">
                        <UserRoundCheck className="h-5 w-5 text-gray-600" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{employee?.name || "Unknown Employee"}</p>
                        <p className="text-sm text-gray-600">
                          Invoice #{String(invoice.id).padStart(4, '0')} • Due: {new Date(invoice.dueDate).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <span className="font-semibold text-gray-900">{formatCurrency(parseFloat(invoice.amount))}</span>
                      <Button 
                        onClick={() => setPaymentModal({ open: true, invoice })}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        <CreditCard className="mr-2 h-4 w-4" />
                        Pay via Stripe
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Search */}
      <Card>
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search employees..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Employees Table */}
      <Card>
        <CardHeader>
          <CardTitle>All Employees</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredEmployees.length === 0 ? (
            <div className="text-center py-12">
              <UserRoundCheck className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No employees found</h3>
              <p className="text-gray-500 mb-4">
                {searchTerm ? "No employees match your search criteria." : "Get started by adding your first employee."}
              </p>
              {!searchTerm && (
                <Button onClick={() => setShowAddModal(true)}>
                  <Plus className="mr-2 h-4 w-4" />
                  Add Your First Employee
                </Button>
              )}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-4 font-medium text-gray-700">Employee</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-700">Employee ID</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-700">Account Number</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-700">Fields</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-700">Role</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-700">Rate</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-700">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredEmployees.map((employee: any) => {
                    const getFieldsDisplay = (fieldsId: any[]) => {
                      if (!fieldsId || !Array.isArray(fieldsId)) return 'No fields assigned';
                      return fieldsId.map(field => field.name).join(', ');
                    };
                    
                    return (
                      <tr key={employee.id} className="border-b border-gray-100 hover:bg-gray-50">
                        <td className="py-3 px-4">
                          <div className="flex items-center">
                            <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center mr-3">
                              <span className="text-gray-600 text-sm font-medium">
                                {employee.name.charAt(0).toUpperCase()}
                              </span>
                            </div>
                            <div>
                              <p className="font-medium text-gray-900">{employee.name}</p>
                              <p className="text-sm text-gray-500">{employee.email}</p>
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <span className="font-mono text-sm text-gray-600">{employee.employee_id}</span>
                        </td>
                        <td className="py-3 px-4">
                          <span className="text-gray-600">
                            {employee.acct_details || 'Not provided'}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <span className="text-sm text-gray-600">
                            {getFieldsDisplay(employee.fields_id)}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <Badge className={getRoleColor(employee.role)}>
                            {employee.role}
                          </Badge>
                        </td>
                        <td className="py-3 px-4">
                          <span className="font-semibold text-green-600">
                            ${employee.rate}/hr
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex space-x-2">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => handleToggleAdmin(employee)}
                              title={employee.role === 'admin' ? "Remove Admin" : "Make Admin"}
                              className={employee.role === 'admin' ? "text-amber-600" : "text-gray-400"}
                            >
                              <Crown className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => handleDeleteUser(employee)}
                              title="Delete User"
                              className="text-red-600 hover:text-red-700"
                            >
                              <UserX className="h-4 w-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Payment Modal */}
      <PaymentModal 
        open={paymentModal.open}
        onClose={() => setPaymentModal({ open: false })}
        invoice={paymentModal.invoice}
      />

      {/* Admin Confirmation Dialog */}
      <AlertDialog open={adminConfirmDialog.open} onOpenChange={(open) => !open && setAdminConfirmDialog({ open: false })}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Make Employee an Admin?</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to make {adminConfirmDialog.employee?.name} an admin? This will give them administrative privileges in the system.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setAdminConfirmDialog({ open: false })}>
              No
            </AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => {
                if (adminConfirmDialog.employee) {
                  makeAdminMutation.mutate(adminConfirmDialog.employee.id);
                }
              }}
              disabled={makeAdminMutation.isPending}
            >
              {makeAdminMutation.isPending ? "Processing..." : "Yes, Make Admin"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete User Confirmation Dialog */}
      <AlertDialog open={deleteConfirmDialog.open} onOpenChange={(open) => !open && setDeleteConfirmDialog({ open: false })}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Employee?</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete {deleteConfirmDialog.employee?.name}? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setDeleteConfirmDialog({ open: false })}>
              No
            </AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => {
                if (deleteConfirmDialog.employee) {
                  deleteUserMutation.mutate(deleteConfirmDialog.employee.id);
                }
              }}
              disabled={deleteUserMutation.isPending}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleteUserMutation.isPending ? "Deleting..." : "Yes, Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
