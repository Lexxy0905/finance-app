import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  FileText, 
  Download,
  Plus,
  Minus,
  Eye,
  Search,
  Mail,
  ChartLine
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { downloadInvoicePDF } from "@/lib/pdfGenerator";
import { getAuthToken } from "@/lib/authHelpers";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface InvoiceItem {
  description: string;
  price: number;
  quantity: number;
}

interface Client {
  id: number;
  name: string;
  email: string;
  address?: string;
  phone?: string;
}

interface QuotationData {
  clientName: string;
  clientAddress: string;
  selectedClientId: string;
  items: InvoiceItem[];
  taxRate: number;
  stripePaymentLink: string;
  notes: string;
}

export default function QuotationTemplate() {
  const [previewMode, setPreviewMode] = useState(false);
  const [formData, setFormData] = useState<QuotationData>({
    clientName: "",
    clientAddress: "",
    selectedClientId: "",
    items: [{ description: "", price: 0, quantity: 1 }],
    taxRate: 9,
    stripePaymentLink: "",
    notes: "",
  });
  const { toast } = useToast();

  // Fetch clients from Xano API
  const { data: clientsResponse, isLoading: loadingClients } = useQuery({
    queryKey: ["xano-clients"],
    queryFn: async () => {
      const authToken = getAuthToken();
      if (!authToken) {
        throw new Error("No authentication token");
      }
      
      const response = await fetch('https://x8ki-letl-twmt.n7.xano.io/api:CUU7m57L/clients', {
        headers: {
          'Authorization': authToken,
          'Content-Type': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch clients');
      }
      
      return response.json();
    },
    enabled: !!getAuthToken()
  });

  // Extract clients array from response with proper error handling
  const clients = Array.isArray(clientsResponse) ? clientsResponse : 
                  (clientsResponse?.items && Array.isArray(clientsResponse.items)) ? clientsResponse.items : [];

  // Calculate totals
  const subtotal = formData.items.reduce((sum, item) => {
    return sum + (item.price * item.quantity);
  }, 0);

  const taxAmount = (subtotal * formData.taxRate) / 100;
  const total = subtotal + taxAmount;

  // Generate invoice number
  const invoiceNumber = `#${Date.now().toString().slice(-6)}`;
  const currentDate = new Date().toLocaleDateString();
  const validUntilDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString();

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const addItem = () => {
    setFormData({
      ...formData,
      items: [...formData.items, { description: "", price: 0, quantity: 1 }]
    });
  };

  const removeItem = (index: number) => {
    if (formData.items.length > 1) {
      const newItems = formData.items.filter((_, i) => i !== index);
      setFormData({ ...formData, items: newItems });
    }
  };

  const updateItem = (index: number, field: keyof InvoiceItem, value: string | number) => {
    const newItems = [...formData.items];
    newItems[index] = { ...newItems[index], [field]: value };
    setFormData({ ...formData, items: newItems });
  };

  // Handle client selection
  const handleClientSelect = (clientId: string) => {
    const selectedClient = clients.find((client: Client) => client.id.toString() === clientId);
    if (selectedClient) {
      setFormData({
        ...formData,
        selectedClientId: clientId,
        clientName: selectedClient.name,
        clientAddress: selectedClient.address || ""
      });
    } else if (clientId === "custom") {
      setFormData({
        ...formData,
        selectedClientId: "custom",
        clientName: "",
        clientAddress: ""
      });
    }
  };

  const handleDownloadPDF = async () => {
    try {
      const invoiceData = {
        id: invoiceNumber,
        title: "Quotation",
        amount: total,
        created_at: new Date().toISOString(),
        description: formData.notes || "",
        status: "pending",
        client: {
          name: formData.clientName,
          email: "",
          address: formData.clientAddress,
        },
        items: formData.items,
        subtotal,
        taxRate: formData.taxRate,
        taxAmount,
        stripePaymentLink: formData.stripePaymentLink,
      };

      await downloadInvoicePDF(invoiceData);
      
      toast({
        title: "Success",
        description: "Quotation PDF generated successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate PDF",
        variant: "destructive",
      });
    }
  };

  // Create invoice in Xano mutation
  const createInvoiceMutation = useMutation({
    mutationFn: async (invoiceData: {
      amount: number;
      title: string;
      client_id: number;
      description: string;
      due_date: string;
      uri: string;
    }) => {
      const authToken = getAuthToken();
      if (!authToken) {
        throw new Error("No authentication token");
      }

      const response = await fetch('https://x8ki-letl-twmt.n7.xano.io/api:CUU7m57L/client_invoices/create_new', {
        method: "POST",
        headers: {
          'Authorization': authToken,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(invoiceData),
      });

      if (!response.ok) {
        throw new Error("Failed to create invoice");
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Invoice created successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: "Failed to create invoice. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Email sending mutation
  const sendEmailMutation = useMutation({
    mutationFn: async (emailData: any) => {
      const response = await fetch("/api/send-quotation-email", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(emailData),
      });

      if (!response.ok) {
        throw new Error("Failed to send email");
      }

      return response.json();
    },
    onSuccess: async (data, variables) => {
      // After email is sent successfully, create the invoice in Xano
      const selectedClient = clients.find((client: Client) => 
        client.id.toString() === formData.selectedClientId
      );

      if (selectedClient) {
        const dueDate = new Date();
        dueDate.setDate(dueDate.getDate() + 30); // 30 days from now
        
        // Create a PDF download URL instead of preview URL
        const pdfDownloadUrl = `/api/download-quotation-pdf/${invoiceNumber}?client=${selectedClient.id}`;
        
        const invoiceData = {
          amount: total,
          title: `Quotation ${invoiceNumber}`,
          client_id: selectedClient.id,
          description: formData.notes || `Quotation for ${formData.items.map(item => item.description).join(', ')}`,
          due_date: dueDate.toISOString().split('T')[0], // Format as YYYY-MM-DD
          uri: pdfDownloadUrl // PDF download URL
        };

        createInvoiceMutation.mutate(invoiceData);
      }

      toast({
        title: "Success",
        description: "Quotation email sent successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: "Failed to send email. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSendEmail = async () => {
    // Get the selected client's email
    const selectedClient = clients.find((client: Client) => 
      client.id.toString() === formData.selectedClientId
    );
    
    const clientEmail = selectedClient?.email;
    
    if (!clientEmail) {
      toast({
        title: "Error",
        description: "Please select a client with an email address to send the quotation.",
        variant: "destructive",
      });
      return;
    }

    const quotationData = {
      clientName: formData.clientName,
      clientAddress: formData.clientAddress,
      items: formData.items,
      taxRate: formData.taxRate,
      stripePaymentLink: formData.stripePaymentLink,
      notes: formData.notes,
      invoiceNumber,
      currentDate,
      validUntilDate,
    };

    sendEmailMutation.mutate({
      quotationData,
      clientEmail,
    });
  };

  if (previewMode) {
    return (
      <div className="max-w-4xl mx-auto p-6 space-y-6">
        <div className="flex items-center justify-between mb-6">
          <Button 
            variant="outline" 
            onClick={() => setPreviewMode(false)}
          >
            Back to Edit
          </Button>
          <div className="flex gap-2">
            <Button 
              variant="outline"
              onClick={handleDownloadPDF}
            >
              <Download className="h-4 w-4 mr-2" />
              Download PDF
            </Button>
            <Button 
              variant="default"
              onClick={handleSendEmail}
              disabled={sendEmailMutation.isPending || createInvoiceMutation.isPending || formData.selectedClientId === "custom" || !formData.selectedClientId}
            >
              <Mail className="h-4 w-4 mr-2" />
              {sendEmailMutation.isPending || createInvoiceMutation.isPending ? "Sending..." : "Send Email"}
            </Button>
          </div>
        </div>

        {/* Invoice Preview */}
        <Card className="max-w-4xl mx-auto bg-white">
          <CardContent className="p-8">
            {/* Header */}
            <div className="flex justify-between items-start mb-8">
              <div className="flex items-center space-x-3">
                <div className="h-12 w-12 bg-primary rounded-lg flex items-center justify-center">
                  <ChartLine className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-semibold text-gray-900">FinanceFlow</h1>
                  <p className="text-sm text-gray-500">Professional Invoicing</p>
                </div>
              </div>
              <div className="text-center">
                <h2 className="text-6xl font-light tracking-wider text-black">
                  Quotation
                </h2>
              </div>
            </div>

            {/* Invoice Details */}
            <div className="flex justify-between items-start mb-8 border-b border-gray-300 pb-4">
              <div className="space-y-1">
                <div className="text-sm">
                  <span className="font-medium">Date:</span> {currentDate}
                </div>
                <div className="text-sm">
                  <span className="font-medium">Valid Until Date:</span> {validUntilDate}
                </div>
              </div>
              <div className="text-sm">
                <span className="font-medium">Invoice Number:</span> {invoiceNumber}
              </div>
            </div>

            {/* Client Info */}
            <div className="flex justify-between mb-8 border-b border-gray-300 pb-4">
              <div>
                <div className="text-sm">
                  <span className="font-medium">To:</span> {formData.clientName}
                </div>
              </div>
              <div className="text-right text-sm whitespace-pre-line">
                {formData.clientAddress}
              </div>
            </div>

            {/* Items Table */}
            <div className="mb-8">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-300">
                    <th className="text-left py-3 font-medium">Item Description</th>
                    <th className="text-right py-3 font-medium">Price</th>
                    <th className="text-right py-3 font-medium">QTY</th>
                    <th className="text-right py-3 font-medium">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {formData.items.map((item, index) => (
                    <tr key={index} className="border-b border-gray-100">
                      <td className="py-4">{item.description}</td>
                      <td className="text-right py-4">{formatCurrency(item.price)}</td>
                      <td className="text-right py-4">{item.quantity}</td>
                      <td className="text-right py-4">{formatCurrency(item.price * item.quantity)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Totals */}
            <div className="flex justify-end mb-8">
              <div className="w-64 space-y-2">
                <div className="flex justify-between border-b border-gray-300 pb-2">
                  <span>Subtotal :</span>
                  <span>{formatCurrency(subtotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Tax ({formData.taxRate}%) :</span>
                  <span>{formatCurrency(taxAmount)}</span>
                </div>
                <div className="flex justify-between font-bold text-lg border-t border-gray-300 pt-2">
                  <span>Total Due :</span>
                  <span>{formatCurrency(total)}</span>
                </div>
              </div>
            </div>



            {/* Payment Link */}
            {formData.stripePaymentLink && (
              <div className="mt-8 p-4 bg-blue-50 rounded-lg border-2 border-blue-200">
                <div className="text-center">
                  <p className="text-sm text-gray-600 mb-2">Pay Online:</p>
                  <a 
                    href={formData.stripePaymentLink} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-block bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    Pay Now with Stripe
                  </a>
                </div>
              </div>
            )}

            {/* Notes */}
            {formData.notes && (
              <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                <h4 className="font-medium mb-2">Notes:</h4>
                <p className="text-sm text-gray-600 whitespace-pre-line">{formData.notes}</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Quotation Template</h2>
          <p className="text-gray-600">Create professional quotations with PDF generation</p>
        </div>
        <Button 
          variant="outline"
          onClick={() => setPreviewMode(true)}
          disabled={!formData.clientName || formData.items.some(item => !item.description)}
        >
          <Eye className="h-4 w-4 mr-2" />
          Preview
        </Button>
      </div>

      {/* Client Information */}
      <Card>
        <CardHeader>
          <CardTitle>Client Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="clientSelect">Select Client</Label>
            <Select 
              value={formData.selectedClientId} 
              onValueChange={handleClientSelect}
            >
              <SelectTrigger>
                <SelectValue placeholder={loadingClients ? "Loading clients..." : "Select a client or enter custom"} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="custom">Enter Custom Client</SelectItem>
                {clients.map((client: Client) => (
                  <SelectItem key={client.id} value={client.id.toString()}>
                    {client.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="clientName">Client Name</Label>
            <Input
              id="clientName"
              placeholder="Johnny & Betty Gibbins"
              value={formData.clientName}
              onChange={(e) => setFormData({ ...formData, clientName: e.target.value })}
              disabled={formData.selectedClientId !== "custom" && formData.selectedClientId !== ""}
            />
          </div>
          
          <div>
            <Label htmlFor="clientAddress">Client Address</Label>
            <Textarea
              id="clientAddress"
              placeholder="321 Rodeo Dr&#10;Old Rochelle, NY 90210"
              value={formData.clientAddress}
              onChange={(e) => setFormData({ ...formData, clientAddress: e.target.value })}
              disabled={formData.selectedClientId !== "custom" && formData.selectedClientId !== ""}
            />
          </div>
        </CardContent>
      </Card>

      {/* Invoice Items */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Invoice Items</CardTitle>
            <Button variant="outline" size="sm" onClick={addItem}>
              <Plus className="h-4 w-4 mr-2" />
              Add Item
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {formData.items.map((item, index) => (
            <div key={index} className="grid grid-cols-12 gap-4 items-end p-4 border rounded-lg">
              <div className="col-span-5">
                <Label>Description</Label>
                <Input
                  placeholder="Architectural design"
                  value={item.description}
                  onChange={(e) => updateItem(index, 'description', e.target.value)}
                />
              </div>
              <div className="col-span-3">
                <Label>Price</Label>
                <Input
                  type="number"
                  step="0.01"
                  placeholder="0.00"
                  value={item.price === 0 ? '' : item.price}
                  onChange={(e) => updateItem(index, 'price', e.target.value === '' ? 0 : parseFloat(e.target.value) || 0)}
                />
              </div>
              <div className="col-span-2">
                <Label>Qty</Label>
                <Input
                  type="number"
                  min="1"
                  placeholder="1"
                  value={item.quantity}
                  onChange={(e) => updateItem(index, 'quantity', parseInt(e.target.value) || 1)}
                />
              </div>
              <div className="col-span-2 flex items-center justify-between">
                <div className="text-right">
                  <Label className="text-sm text-gray-500">Amount</Label>
                  <div className="font-medium">
                    {formatCurrency(item.price * item.quantity)}
                  </div>
                </div>
                {formData.items.length > 1 && (
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => removeItem(index)}
                    className="text-red-500 hover:text-red-700"
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>
          ))}

          {/* Totals Display */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="flex justify-end">
              <div className="w-64 space-y-2">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span>{formatCurrency(subtotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Tax ({formData.taxRate}%):</span>
                  <span>{formatCurrency(taxAmount)}</span>
                </div>
                <div className="flex justify-between font-bold text-lg border-t pt-2">
                  <span>Total:</span>
                  <span>{formatCurrency(total)}</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Settings */}
      <Card>
        <CardHeader>
          <CardTitle>Invoice Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="taxRate">Tax Rate (%)</Label>
            <Input
              id="taxRate"
              type="number"
              step="0.1"
              min="0"
              max="100"
              placeholder="9"
              value={formData.taxRate}
              onChange={(e) => setFormData({ ...formData, taxRate: parseFloat(e.target.value) || 0 })}
            />
          </div>
          <div>
            <Label htmlFor="stripePaymentLink">Stripe Payment Link (Optional)</Label>
            <Input
              id="stripePaymentLink"
              placeholder="https://buy.stripe.com/..."
              value={formData.stripePaymentLink}
              onChange={(e) => setFormData({ ...formData, stripePaymentLink: e.target.value })}
            />
          </div>
          <div>
            <Label htmlFor="notes">Notes (Optional)</Label>
            <Textarea
              id="notes"
              placeholder="Additional notes or payment terms..."
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
            />
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="flex justify-end space-x-3">
        <Button variant="outline" onClick={() => setPreviewMode(true)}>
          <Eye className="h-4 w-4 mr-2" />
          Preview
        </Button>
        <Button onClick={handleDownloadPDF}>
          <Download className="h-4 w-4 mr-2" />
          Generate PDF
        </Button>
      </div>
    </div>
  );
}