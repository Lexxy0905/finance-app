import { useQuery } from "@tanstack/react-query";
import { getAuthToken } from "@/lib/authHelpers";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import {
  DollarSign,
  UserRoundCheck,
  TrendingUp,
  FileText,
  Eye,
  Download
} from "lucide-react";
import Chart from "react-apexcharts";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { downloadInvoicePDF } from "@/lib/pdfGenerator";

export default function Dashboard() {
  const [chartPeriod, setChartPeriod] = useState("6");
  const { toast } = useToast();

  // Remove the stats query since we'll calculate from existing data

  const { data: chartData } = useQuery({
    queryKey: ["dashboard-chart", chartPeriod],
    queryFn: async () => {
      const authToken = 'eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIiwiemlwIjoiREVGIn0.fWGcBOScddhTAjrZuSg4t11ji7LzIgHRLPzn0Zs1iunwdtjtGNDLrulsG7gOLO5rllNmqZiXy3OS2DSRCgKefUnJmcM57NPW.T0LS1eFzN_Z1QqCGLTkeRQ.IUz7DhL1cSMm8WKkcAIwoUV6hKLNT33eAni9BdnJAVop0iVX5mtALNRgOnk7HGmSsQvsi4YiAywcWpzHsmKixE8Gp7KtF9HfjSAktv-YPILcKZ7D7GuggCJvl8YEUwJd5fixgnAiyIbtSf1Cz9pr2tq1mNt-w5KM7FB0S5RpRfs.9VwfyAGPryrar0MtjzvQ0OQhc4du4wFe9aSKfpLf_2k';
      
      const response = await fetch(`https://x8ki-letl-twmt.n7.xano.io/api:CUU7m57L/client_invoices/get/stats?month=${chartPeriod}`, {
        headers: {
          'Authorization': authToken,
          'Content-Type': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch chart data');
      }
      
      return response.json();
    },
  });

  // Fetch client invoices from Xano
  const { data: clientInvoices, isLoading: invoicesLoading } = useQuery({
    queryKey: ["client-invoices-dashboard"],
    queryFn: async () => {
      const authToken = 'eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIiwiemlwIjoiREVGIn0.fWGcBOScddhTAjrZuSg4t11ji7LzIgHRLPzn0Zs1iunwdtjtGNDLrulsG7gOLO5rllNmqZiXy3OS2DSRCgKefUnJmcM57NPW.T0LS1eFzN_Z1QqCGLTkeRQ.IUz7DhL1cSMm8WKkcAIwoUV6hKLNT33eAni9BdnJAVop0iVX5mtALNRgOnk7HGmSsQvsi4YiAywcWpzHsmKixE8Gp7KtF9HfjSAktv-YPILcKZ7D7GuggCJvl8YEUwJd5fixgnAiyIbtSf1Cz9pr2tq1mNt-w5KM7FB0S5RpRfs.9VwfyAGPryrar0MtjzvQ0OQhc4du4wFe9aSKfpLf_2k';
      
      const response = await fetch('https://x8ki-letl-twmt.n7.xano.io/api:CUU7m57L/client_invoices', {
        headers: {
          'Authorization': authToken,
          'Content-Type': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch client invoices');
      }
      
      return response.json();
    },
  });

  // Fetch users from Xano
  const { data: users } = useQuery({
    queryKey: ["users-dashboard"],
    queryFn: async () => {
      const authToken = 'eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIiwiemlwIjoiREVGIn0.fWGcBOScddhTAjrZuSg4t11ji7LzIgHRLPzn0Zs1iunwdtjtGNDLrulsG7gOLO5rllNmqZiXy3OS2DSRCgKefUnJmcM57NPW.T0LS1eFzN_Z1QqCGLTkeRQ.IUz7DhL1cSMm8WKkcAIwoUV6hKLNT33eAni9BdnJAVop0iVX5mtALNRgOnk7HGmSsQvsi4YiAywcWpzHsmKixE8Gp7KtF9HfjSAktv-YPILcKZ7D7GuggCJvl8YEUwJd5fixgnAiyIbtSf1Cz9pr2tq1mNt-w5KM7FB0S5RpRfs.9VwfyAGPryrar0MtjzvQ0OQhc4du4wFe9aSKfpLf_2k';
      
      const response = await fetch('https://x8ki-letl-twmt.n7.xano.io/api:CUU7m57L/user', {
        headers: {
          'Authorization': authToken,
          'Content-Type': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch users');
      }
      
      const data = await response.json();
      // Return the user array from Xano response
      return data.user || [];
    },
  });

  // Helper functions for client invoices
  const handleDownloadPDF = async (invoice: any) => {
    try {
      const invoiceData = {
        id: invoice.id,
        title: invoice.title,
        amount: invoice.amount,
        created_at: invoice.created_at,
        due_date_uri: invoice.due_date_uri,
        description: invoice.description,
        status: invoice.status,
        client: {
          name: invoice.client_name || 'Client Name',
          email: invoice.client_email || '',
          address: invoice.client_address || '',
          phone: invoice.client_phone || ''
        }
      };

      await downloadInvoicePDF(invoiceData);
      
      toast({
        title: "Success",
        description: "Invoice PDF downloaded successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate PDF invoice",
        variant: "destructive",
      });
    }
  };

  const formatCurrency = (amount: string | number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(typeof amount === 'string' ? parseFloat(amount) : amount);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'paid':
        return 'default';
      case 'pending':
        return 'secondary';
      case 'overdue':
        return 'destructive';
      default:
        return 'secondary';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'paid':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'overdue':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const isOverdue = (dueDate: string) => {
    return new Date(dueDate) < new Date();
  };

  const getInvoiceStatus = (invoice: any) => {
    if (invoice.status === 'paid') return 'paid';
    if (invoice.due_date && isOverdue(invoice.due_date)) return 'overdue';
    return 'pending';
  };

  // Prepare invoice data for table (first 5 invoices)
  const invoicesArray = clientInvoices || [];
  const recentInvoices = invoicesArray.slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Main Layout - Chart Left, Cards Right */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Side - Income Chart (2/3 width) */}
        <div className="lg:col-span-2">
          <Card className="h-full">
            <CardHeader className="pb-4">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-lg font-medium text-gray-700 mb-2">Income</h3>
                  <div className="flex items-baseline gap-2">
                    <span className="text-sm text-gray-500">Total:</span>
                    <span className="text-2xl font-bold text-gray-900">
                      {chartData?.total ? formatCurrency(chartData.total) : '$47,619.93'}
                    </span>
                  </div>
                </div>
                <Select value={chartPeriod} onValueChange={setChartPeriod}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Select period" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="3">Last 3 Months</SelectItem>
                    <SelectItem value="6">Last 6 Months</SelectItem>
                    <SelectItem value="9">Last 9 Months</SelectItem>
                    <SelectItem value="12">Last 12 Months</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <Chart
                  options={{
                    chart: {
                      type: 'area',
                      toolbar: {
                        show: false
                      },
                      background: 'transparent',
                      sparkline: {
                        enabled: false
                      }
                    },
                    colors: ['#10B981'],
                    stroke: {
                      curve: 'smooth',
                      width: 3
                    },
                    fill: {
                      type: 'gradient',
                      gradient: {
                        shadeIntensity: 1,
                        opacityFrom: 0.4,
                        opacityTo: 0.1,
                        stops: [0, 90, 100]
                      }
                    },
                    dataLabels: {
                      enabled: false
                    },
                    grid: {
                      borderColor: '#e5e5e5',
                      strokeDashArray: 3,
                      padding: {
                        top: 0,
                        right: 0,
                        bottom: 20,
                        left: 0
                      }
                    },
                    xaxis: {
                      categories: chartData?.categories || ['Jul. 2024', 'Aug. 2024', 'Sept. 2024', 'Oct. 2024', 'Nov. 2024', 'Dec. 2024'],
                      labels: {
                        show: true,
                        style: {
                          colors: '#9CA3AF',
                          fontSize: '12px',
                          fontWeight: 400
                        },
                        offsetY: 0
                      },
                      axisBorder: {
                        show: true,
                        color: '#E5E7EB',
                        height: 1,
                        width: '100%',
                        offsetX: 0,
                        offsetY: 0
                      },
                      axisTicks: {
                        show: true,
                        borderType: 'solid',
                        color: '#E5E7EB',
                        height: 6,
                        offsetX: 0,
                        offsetY: 0
                      }
                    },
                    yaxis: {
                      labels: {
                        formatter: (value) => {
                          if (value >= 1000000) {
                            return `$${(value / 1000000).toFixed(1)}M`;
                          } else if (value >= 1000) {
                            return `$${(value / 1000).toFixed(0)}k`;
                          } else {
                            return `$${value}`;
                          }
                        },
                        style: {
                          colors: '#9CA3AF',
                          fontSize: '12px',
                          fontWeight: 400
                        }
                      },
                      min: 0
                    },
                    tooltip: {
                      y: {
                        formatter: (value) => formatCurrency(value)
                      },
                      theme: 'light'
                    },
                    markers: {
                      size: 4,
                      colors: ['#10B981'],
                      strokeColors: '#ffffff',
                      strokeWidth: 2,
                      hover: {
                        size: 6
                      }
                    },
                    theme: {
                      mode: 'light'
                    }
                  }}
                  series={[
                    {
                      name: 'Income',
                      data: chartData?.data || [3000, 2500, 1800, 4500, 6200, 29000]
                    }
                  ]}
                  type="area"
                  height={300}
                />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Side - Summary Cards (1/3 width) */}
        <div className="space-y-6">
          
          {/* Outstanding Client Invoices */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-medium text-gray-500">Outstanding Client Invoices</h3>
              </div>
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <TrendingUp className="h-6 w-6 text-blue-600" />
                </div>
                <div className="text-3xl font-bold text-gray-900">
                  {invoicesArray.filter(inv => inv.status !== 'paid').length}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Unpaid Employee Invoices */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-medium text-gray-500">Unpaid Employee Invoices</h3>
              </div>
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 bg-red-100 rounded-lg flex items-center justify-center">
                  <div className="h-6 w-6 bg-red-600 rounded-full flex items-center justify-center">
                    <span className="text-white text-xs font-bold">!</span>
                  </div>
                </div>
                <div className="text-3xl font-bold text-gray-900">
                  0
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Total Users */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-medium text-gray-500">Total Users</h3>
              </div>
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 bg-gray-100 rounded-lg flex items-center justify-center">
                  <UserRoundCheck className="h-6 w-6 text-gray-600" />
                </div>
                <div className="text-3xl font-bold text-gray-900">
                  {Array.isArray(users) ? users.length : 0}
                </div>
              </div>
            </CardContent>
          </Card>

        </div>
      </div>

      {/* Recent Client Invoices Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Recent Client Invoices</CardTitle>
            <div className="text-sm text-gray-500">
              Showing latest 5 invoices
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {invoicesLoading ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="animate-pulse bg-gray-200 rounded h-16" />
              ))}
            </div>
          ) : recentInvoices.length === 0 ? (
            <div className="text-center py-8">
              <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No client invoices found</h3>
              <p className="text-gray-500">Client invoices will appear here once created.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-4 font-semibold text-gray-900 text-sm">Invoice</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-900 text-sm">Client</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-900 text-sm">Amount</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-900 text-sm">Status</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-900 text-sm">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {recentInvoices.map((invoice: any) => {
                    const status = getInvoiceStatus(invoice);
                    return (
                      <tr key={invoice.id} className="hover:bg-gray-50 transition-colors duration-150">
                        <td className="py-3 px-4">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-8 w-8 bg-blue-100 rounded-lg flex items-center justify-center">
                              <FileText className="h-4 w-4 text-blue-600" />
                            </div>
                            <div className="ml-3">
                              <div className="font-semibold text-gray-900 text-sm">
                                #{invoice.id}
                              </div>
                              {invoice.title && (
                                <div className="text-xs text-gray-500 truncate max-w-32">
                                  {invoice.title}
                                </div>
                              )}
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-medium text-gray-900 text-sm">
                            {invoice.client_name || invoice.client?.name || 'Unknown Client'}
                          </div>
                          {(invoice.client_email || invoice.client?.email) && (
                            <div className="text-xs text-gray-500">
                              {invoice.client_email || invoice.client?.email}
                            </div>
                          )}
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-bold text-gray-900">
                            {formatCurrency(invoice.amount || 0)}
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <Badge 
                            variant={getStatusBadgeVariant(status)}
                            className={`${getStatusColor(status)} px-2 py-1 text-xs font-semibold`}
                          >
                            {status.charAt(0).toUpperCase() + status.slice(1)}
                          </Badge>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex space-x-1">
                            <Button 
                              variant="outline" 
                              size="sm"
                              className="hover:bg-blue-50 hover:border-blue-300 hover:text-blue-700 h-8 px-2"
                              onClick={() => {
                                if (invoice.invoice_uri) {
                                  window.open(invoice.invoice_uri, '_blank');
                                } else {
                                  toast({
                                    title: "No Invoice Available",
                                    description: "This invoice doesn't have a document URL",
                                    variant: "destructive",
                                  });
                                }
                              }}
                              disabled={!invoice.invoice_uri}
                            >
                              <Eye className="h-3 w-3 mr-1" />
                              View
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm"
                              className="hover:bg-green-50 hover:border-green-300 hover:text-green-700 h-8 px-2"
                              onClick={() => handleDownloadPDF(invoice)}
                            >
                              <Download className="h-3 w-3 mr-1" />
                              PDF
                            </Button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

    </div>
  );
}