import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { getAuthToken } from "@/lib/authHelpers";
import { Users, UserRoundCheck } from "lucide-react";

interface CreateInvoiceModalProps {
  open: boolean;
  onClose: () => void;
}

export default function CreateInvoiceModal({ open, onClose }: CreateInvoiceModalProps) {
  const [invoiceType, setInvoiceType] = useState<"client" | "employee">("client");
  const [selectedRecipient, setSelectedRecipient] = useState("");
  const [amount, setAmount] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [description, setDescription] = useState("");
  const [title, setTitle] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: clients, isLoading: clientsLoading } = useQuery({
    queryKey: ["xano-clients"],
    queryFn: async () => {
      const authToken = getAuthToken();
      if (!authToken) {
        throw new Error("No authentication token");
      }
      
      const response = await fetch('https://x8ki-letl-twmt.n7.xano.io/api:CUU7m57L/clients', {
        headers: {
          'Authorization': authToken,
          'Content-Type': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch clients');
      }
      
      const data = await response.json();
      console.log('Xano clients data:', data); // Debug log
      return data.items || []; // Return the items array from the response
    },
    enabled: open && invoiceType === "client" && !!getAuthToken(), // Only fetch when modal is open, client type is selected, and token exists
  });

  const { data: employees, isLoading: employeesLoading } = useQuery({
    queryKey: ["xano-users"],
    queryFn: async () => {
      const authToken = getAuthToken();
      if (!authToken) {
        throw new Error("No authentication token");
      }
      
      const response = await fetch('https://x8ki-letl-twmt.n7.xano.io/api:CUU7m57L/user', {
        headers: {
          'Authorization': authToken,
          'Content-Type': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch users');
      }
      
      const data = await response.json();
      console.log('Xano users data:', data); // Debug log
      return data.user || []; // Return the user array from the response
    },
    enabled: open && invoiceType === "employee" && !!getAuthToken(), // Only fetch when modal is open, employee type is selected, and token exists
  });

  const createInvoiceMutation = useMutation({
    mutationFn: async (data: any) => {
      if (data.invoiceType === "client") {
        // Use Xano API for client invoices
        const authToken = getAuthToken();
        if (!authToken) {
          throw new Error("No authentication token");
        }
        
        const response = await fetch('https://x8ki-letl-twmt.n7.xano.io/api:CUU7m57L/client_invoices/create', {
          method: 'POST',
          headers: {
            'Authorization': authToken,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            amount: data.amount,
            title: data.title,
            client: data.clientId,
            description: data.description,
            data: data.data || {},
            due_date_uri: data.dueDate
          })
        });
        
        if (!response.ok) {
          throw new Error('Failed to create client invoice');
        }
        
        return response.json();
      } else {
        // Use internal API for employee invoices
        const response = await apiRequest("POST", "/api/invoices", data);
        return response.json();
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      queryClient.invalidateQueries({ queryKey: ["xano-clients"] });
      toast({
        title: "Success",
        description: "Invoice created successfully",
      });
      handleClose();
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: `Failed to create invoice: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedRecipient || !amount || !dueDate) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    if (invoiceType === "client" && !title) {
      toast({
        title: "Validation Error",
        description: "Please provide a title for the client invoice",
        variant: "destructive",
      });
      return;
    }

    const invoiceData = {
      invoiceType,
      clientId: invoiceType === "client" ? parseInt(selectedRecipient) : null,
      employeeId: invoiceType === "employee" ? parseInt(selectedRecipient) : null,
      amount: parseFloat(amount),
      dueDate: dueDate,
      title: title,
      status: "unpaid",
      description: description || null,
      data: {} // Additional data field for Xano API
    };

    createInvoiceMutation.mutate(invoiceData);
  };

  const handleClose = () => {
    setInvoiceType("client");
    setSelectedRecipient("");
    setAmount("");
    setDueDate("");
    setDescription("");
    setTitle("");
    onClose();
  };

  const recipients = invoiceType === "client" ? clients : employees;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create New Invoice</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Invoice Type */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Invoice Type</Label>
            <RadioGroup 
              value={invoiceType} 
              onValueChange={(value: "client" | "employee") => {
                setInvoiceType(value);
                setSelectedRecipient("");
              }}
              className="grid grid-cols-2 gap-4"
            >
              <div>
                <RadioGroupItem value="client" id="client" className="peer sr-only" />
                <Label
                  htmlFor="client"
                  className="flex items-center p-4 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50 peer-checked:border-blue-500 peer-checked:bg-blue-50"
                >
                  <Users className="mr-3 h-5 w-5" />
                  <div>
                    <div className="font-medium text-gray-900">Client Invoice</div>
                    <div className="text-sm text-gray-500">Bill a client for services</div>
                  </div>
                </Label>
              </div>
              <div>
                <RadioGroupItem value="employee" id="employee" className="peer sr-only" />
                <Label
                  htmlFor="employee"
                  className="flex items-center p-4 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50 peer-checked:border-blue-500 peer-checked:bg-blue-50"
                >
                  <UserRoundCheck className="mr-3 h-5 w-5" />
                  <div>
                    <div className="font-medium text-gray-900">Employee Invoice</div>
                    <div className="text-sm text-gray-500">Pay an employee</div>
                  </div>
                </Label>
              </div>
            </RadioGroup>
          </div>

          {/* Recipient Selection */}
          <div className="space-y-2">
            <Label htmlFor="recipient">
              Select {invoiceType === "client" ? "Client" : "Employee"}
            </Label>
            <Select value={selectedRecipient} onValueChange={setSelectedRecipient}>
              <SelectTrigger>
                <SelectValue placeholder={`Choose a ${invoiceType}...`} />
              </SelectTrigger>
              <SelectContent>
                {(invoiceType === "client" && clientsLoading) || (invoiceType === "employee" && employeesLoading) ? (
                  <SelectItem value="loading" disabled>
                    Loading {invoiceType}s...
                  </SelectItem>
                ) : !recipients || recipients.length === 0 ? (
                  <SelectItem value="none" disabled>
                    No {invoiceType}s available
                  </SelectItem>
                ) : Array.isArray(recipients) ? (
                  recipients.map((recipient: any) => (
                    <SelectItem key={recipient.id} value={recipient.id?.toString() || ""}>
                      {recipient.name}
                    </SelectItem>
                  ))
                ) : (
                  <SelectItem value="error" disabled>
                    Failed to load {invoiceType}s
                  </SelectItem>
                )}
              </SelectContent>
            </Select>
          </div>

          {/* Title (for client invoices) */}
          {invoiceType === "client" && (
            <div className="space-y-2">
              <Label htmlFor="title">Invoice Title</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter invoice title..."
                required
              />
            </div>
          )}

          {/* Amount and Due Date */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="amount">Amount</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                  $
                </span>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="pl-8"
                  placeholder="0.00"
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="dueDate">Due Date</Label>
              <Input
                id="dueDate"
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                required
              />
            </div>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description">Description (Optional)</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Enter invoice description..."
              rows={3}
            />
          </div>

          {/* Actions */}
          <div className="flex justify-end space-x-3 pt-6 border-t">
            <Button type="button" variant="outline" onClick={handleClose}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={createInvoiceMutation.isPending}
            >
              {createInvoiceMutation.isPending ? "Creating..." : "Create Invoice"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
