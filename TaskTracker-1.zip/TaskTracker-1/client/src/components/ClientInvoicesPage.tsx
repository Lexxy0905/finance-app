import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  FileText, 
  Search, 
  Eye,
  ChevronLeft,
  ChevronRight,
  Plus,
  Download
} from "lucide-react";
import { getAuthToken } from "@/lib/authHelpers";
import { useToast } from "@/hooks/use-toast";
import CreateInvoiceModal from "./CreateInvoiceModal";
import { downloadInvoicePDF } from "@/lib/pdfGenerator";

export default function ClientInvoicesPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurPage] = useState(1);
  const [perPage] = useState(10);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const { toast } = useToast();

  // Handle PDF download
  const handleDownloadPDF = async (invoice: any) => {
    try {
      const invoiceData = {
        id: invoice.id,
        title: invoice.title,
        amount: invoice.amount,
        created_at: invoice.created_at,
        due_date_uri: invoice.due_date_uri,
        description: invoice.description,
        status: invoice.status,
        client: {
          name: invoice.client_name || 'Client Name',
          email: invoice.client_email || '',
          address: invoice.client_address || '',
          phone: invoice.client_phone || ''
        }
      };

      await downloadInvoicePDF(invoiceData);
      
      toast({
        title: "Success",
        description: "Invoice PDF downloaded successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate PDF invoice",
        variant: "destructive",
      });
    }
  };

  // Fetch client invoices
  const { data: invoicesData, isLoading } = useQuery({
    queryKey: ["client-invoices", searchTerm],
    queryFn: async () => {
      const authToken = getAuthToken();
      if (!authToken) {
        throw new Error("No authentication token");
      }
      
      const params = new URLSearchParams({
        ...(searchTerm && { search: searchTerm })
      });
      
      const url = `https://x8ki-letl-twmt.n7.xano.io/api:CUU7m57L/client_invoices${params.toString() ? `?${params}` : ''}`;
      
      const response = await fetch(url, {
        headers: {
          'Authorization': authToken,
          'Content-Type': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch client invoices');
      }
      
      return response.json();
    },
    enabled: !!getAuthToken()
  });

  const formatCurrency = (amount: string | number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(typeof amount === 'string' ? parseFloat(amount) : amount);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'paid':
        return 'default';
      case 'pending':
        return 'secondary';
      case 'overdue':
        return 'destructive';
      default:
        return 'secondary';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'paid':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'overdue':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const isOverdue = (dueDate: string) => {
    return new Date(dueDate) < new Date();
  };

  const getInvoiceStatus = (invoice: any) => {
    if (invoice.status === 'paid') return 'paid';
    if (invoice.due_date && isOverdue(invoice.due_date)) return 'overdue';
    return 'pending';
  };

  // Since the API returns an array directly, we'll handle pagination on frontend
  const invoices = invoicesData || [];
  const filteredInvoices = invoices.filter((invoice: any) => 
    searchTerm === "" || 
    invoice.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    invoice.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    invoice.id?.toString().includes(searchTerm)
  );
  
  const totalPages = Math.ceil(filteredInvoices.length / perPage);
  const paginatedInvoices = filteredInvoices.slice(
    (currentPage - 1) * perPage,
    currentPage * perPage
  );

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse bg-gray-200 rounded h-8 w-64" />
        <div className="animate-pulse bg-gray-200 rounded-lg h-32" />
        <div className="animate-pulse bg-gray-200 rounded-lg h-96" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Client Invoices</h2>
          <p className="text-gray-600">Manage and track client invoice billing</p>
        </div>
        <Button onClick={() => setShowCreateModal(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Create Invoice
        </Button>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search client invoices..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Invoices Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Client Invoices</CardTitle>
            <div className="text-sm text-gray-500">
              {filteredInvoices.length} total invoices
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {paginatedInvoices.length === 0 ? (
            <div className="text-center py-12">
              <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No client invoices found</h3>
              <p className="text-gray-500 mb-4">
                {searchTerm 
                  ? "No invoices match your search criteria." 
                  : "Client invoices will appear here once created."
                }
              </p>
              {!searchTerm && (
                <Button onClick={() => setShowCreateModal(true)}>
                  <Plus className="mr-2 h-4 w-4" />
                  Create Your First Invoice
                </Button>
              )}
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr className="border-b border-gray-200">
                      <th className="text-left py-4 px-6 font-semibold text-gray-900 text-sm uppercase tracking-wide">
                        Invoice ID
                      </th>
                      <th className="text-left py-4 px-6 font-semibold text-gray-900 text-sm uppercase tracking-wide">
                        Client
                      </th>
                      <th className="text-left py-4 px-6 font-semibold text-gray-900 text-sm uppercase tracking-wide">
                        Title
                      </th>
                      <th className="text-left py-4 px-6 font-semibold text-gray-900 text-sm uppercase tracking-wide">
                        Amount
                      </th>
                      <th className="text-left py-4 px-6 font-semibold text-gray-900 text-sm uppercase tracking-wide">
                        Due Date
                      </th>
                      <th className="text-left py-4 px-6 font-semibold text-gray-900 text-sm uppercase tracking-wide">
                        Status
                      </th>
                      <th className="text-left py-4 px-6 font-semibold text-gray-900 text-sm uppercase tracking-wide">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {paginatedInvoices.map((invoice: any) => {
                      const status = getInvoiceStatus(invoice);
                      return (
                        <tr key={invoice.id} className="hover:bg-gray-50 transition-colors duration-150">
                          <td className="py-4 px-6">
                            <div className="flex items-center">
                              <div className="flex-shrink-0 h-10 w-10 bg-blue-100 rounded-lg flex items-center justify-center">
                                <FileText className="h-5 w-5 text-blue-600" />
                              </div>
                              <div className="ml-4">
                                <div className="font-semibold text-gray-900">
                                  #{invoice.id}
                                </div>
                                {invoice.created_at && (
                                  <div className="text-sm text-gray-500">
                                    {formatDate(invoice.created_at)}
                                  </div>
                                )}
                              </div>
                            </div>
                          </td>
                          <td className="py-4 px-6">
                            <div>
                              <div className="font-medium text-gray-900">
                                {invoice.client_name || invoice.client?.name || 'Unknown Client'}
                              </div>
                              {(invoice.client_email || invoice.client?.email) && (
                                <div className="text-sm text-gray-500">
                                  {invoice.client_email || invoice.client?.email}
                                </div>
                              )}
                            </div>
                          </td>
                          <td className="py-4 px-6">
                            <div>
                              <div className="font-medium text-gray-900 max-w-xs">
                                {invoice.title || 'No title'}
                              </div>
                              {invoice.description && (
                                <div className="text-sm text-gray-500 truncate max-w-xs">
                                  {invoice.description}
                                </div>
                              )}
                            </div>
                          </td>
                          <td className="py-4 px-6">
                            <div className="text-lg font-bold text-gray-900">
                              {formatCurrency(invoice.amount || 0)}
                            </div>
                          </td>
                          <td className="py-4 px-6">
                            <div className="text-sm text-gray-900">
                              {invoice.due_date ? formatDate(invoice.due_date) : (
                                <span className="text-gray-400 italic">No due date</span>
                              )}
                            </div>
                          </td>
                          <td className="py-4 px-6">
                            <Badge 
                              variant={getStatusBadgeVariant(status)}
                              className={`${getStatusColor(status)} px-3 py-1 text-xs font-semibold`}
                            >
                              {status.charAt(0).toUpperCase() + status.slice(1)}
                            </Badge>
                          </td>
                          <td className="py-4 px-6">
                            <div className="flex space-x-2">
                              <Button 
                                variant="outline" 
                                size="sm"
                                className="hover:bg-blue-50 hover:border-blue-300 hover:text-blue-700"
                                onClick={() => {
                                  if (invoice.invoice_uri) {
                                    window.open(invoice.invoice_uri, '_blank');
                                  } else {
                                    toast({
                                      title: "No Invoice Available",
                                      description: "This invoice doesn't have a document URL",
                                      variant: "destructive",
                                    });
                                  }
                                }}
                                disabled={!invoice.invoice_uri}
                              >
                                <Eye className="h-4 w-4 mr-1" />
                                View
                              </Button>
                              <Button 
                                variant="outline" 
                                size="sm"
                                className="hover:bg-green-50 hover:border-green-300 hover:text-green-700"
                                onClick={() => handleDownloadPDF(invoice)}
                              >
                                <Download className="h-4 w-4 mr-1" />
                                PDF
                              </Button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between pt-4">
                  <div className="text-sm text-gray-500">
                    Page {currentPage} of {totalPages}
                  </div>
                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurPage(currentPage - 1)}
                      disabled={currentPage === 1}
                    >
                      <ChevronLeft className="h-4 w-4" />
                      Previous
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurPage(currentPage + 1)}
                      disabled={currentPage === totalPages}
                    >
                      Next
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {/* Create Invoice Modal */}
      <CreateInvoiceModal 
        open={showCreateModal}
        onClose={() => setShowCreateModal(false)}
      />
    </div>
  );
}