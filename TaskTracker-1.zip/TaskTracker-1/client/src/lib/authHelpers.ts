// Helper functions for authentication
export function getAuthToken(): string | null {
  // Try localStorage first, then cookies for the dynamic auth token
  let token = localStorage.getItem("authToken");
  
  if (!token) {
    // Try to get from cookie (this will be set after user logs in via Xano)
    const cookies = document.cookie.split(';');
    const authCookie = cookies.find(cookie => cookie.trim().startsWith('XANO_AUTH_TOKEN='));
    if (authCookie) {
      token = authCookie.split('=')[1];
      // Sync back to localStorage for faster access
      localStorage.setItem("authToken", token);
    }
  }
  
  return token;
}

export function getCookieValue(name: string): string | null {
  const cookies = document.cookie.split(';');
  const cookie = cookies.find(c => c.trim().startsWith(`${name}=`));
  return cookie ? cookie.split('=')[1] : null;
}

export function setAuthToken(token: string): void {
  // Store in localStorage for quick access
  localStorage.setItem("authToken", token);
  // Store in cookie for persistence
  document.cookie = `XANO_AUTH_TOKEN=${token}; path=/; max-age=${7 * 24 * 60 * 60}`; // 7 days
}

export function removeAuthToken(): void {
  localStorage.removeItem("authToken");
  localStorage.removeItem("userData");
  // Clear both old and new cookie names
  document.cookie = "authToken=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT";
  document.cookie = "XANO_AUTH_TOKEN=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT";
}