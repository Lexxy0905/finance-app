import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';
import { saveAs } from 'file-saver';

interface InvoiceData {
  id: string | number;
  title: string;
  amount: number;
  created_at: string;
  due_date_uri?: string;
  description?: string;
  status: string;
  client?: {
    name: string;
    email: string;
    address?: string;
    phone?: string;
  };
  items?: Array<{
    description: string;
    price: number;
    quantity: number;
  }>;
  subtotal?: number;
  taxRate?: number;
  taxAmount?: number;
  stripePaymentLink?: string;
}

interface CompanyInfo {
  name: string;
  address: string;
  phone: string;
  email: string;
  website?: string;
}

export async function generateInvoicePDF(invoice: InvoiceData, companyInfo?: CompanyInfo) {
  // Create a new PDF document
  const pdfDoc = await PDFDocument.create();
  const page = pdfDoc.addPage([612, 792]); // Standard letter size
  
  // Get fonts
  const helveticaFont = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const helveticaBoldFont = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  
  const { width, height } = page.getSize();
  const margin = 50;
  
  // Colors
  const textColor = rgb(0, 0, 0); // Pure black for text
  const grayColor = rgb(0.4, 0.4, 0.4);
  const lightGray = rgb(0.9, 0.9, 0.9);
  
  let yPosition = height - margin;
  
  // Finance Flow logo and branding (top left)
  const logoSize = 40;
  const primaryBlue = rgb(0.37, 0.45, 0.93); // Blue color for logo
  
  // Draw logo background
  page.drawRectangle({
    x: margin,
    y: yPosition - logoSize,
    width: logoSize,
    height: logoSize,
    color: primaryBlue,
  });
  
  // Draw "FF" text in logo
  page.drawText('FF', {
    x: margin + 10,
    y: yPosition - 25,
    size: 16,
    font: helveticaBoldFont,
    color: rgb(1, 1, 1),
  });
  
  // Finance Flow text
  page.drawText('Finance Flow', {
    x: margin + logoSize + 10,
    y: yPosition - 15,
    size: 16,
    font: helveticaBoldFont,
    color: primaryBlue,
  });
  
  page.drawText('Professional Invoicing', {
    x: margin + logoSize + 10,
    y: yPosition - 30,
    size: 10,
    font: helveticaFont,
    color: grayColor,
  });
  
  // Large "Quotation" title - right side
  const quotationText = "Quotation";
  const quotationWidth = helveticaBoldFont.widthOfTextAtSize(quotationText, 48);
  page.drawText(quotationText, {
    x: width - margin - quotationWidth,
    y: yPosition - 20,
    size: 48,
    font: helveticaBoldFont,
    color: textColor,
  });

  // Add "RECOMMENDED" badge below the quotation title
  const recommendedText = "RECOMMENDED";
  const recommendedWidth = helveticaFont.widthOfTextAtSize(recommendedText, 10);
  
  // Draw badge background
  page.drawRectangle({
    x: width - margin - recommendedWidth - 15,
    y: yPosition - 55,
    width: recommendedWidth + 10,
    height: 15,
    color: rgb(0.2, 0.7, 0.2), // Green background
  });
  
  // Draw recommended text
  page.drawText(recommendedText, {
    x: width - margin - recommendedWidth - 10,
    y: yPosition - 52,
    size: 10,
    font: helveticaBoldFont,
    color: rgb(1, 1, 1), // White text
  });
  
  yPosition -= 80;
  
  // Invoice details section
  const currentDate = new Date(invoice.created_at).toLocaleDateString();
  const validUntilDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString();
  
  // Draw border line
  page.drawLine({
    start: { x: margin, y: yPosition },
    end: { x: width - margin, y: yPosition },
    thickness: 1,
    color: lightGray,
  });
  yPosition -= 20;
  
  // Date info (left side) and Invoice number (right side)
  page.drawText(`Date: ${currentDate}`, {
    x: margin,
    y: yPosition,
    size: 10,
    font: helveticaFont,
    color: textColor,
  });
  
  page.drawText(`Valid Until Date: ${validUntilDate}`, {
    x: margin,
    y: yPosition - 15,
    size: 10,
    font: helveticaFont,
    color: textColor,
  });
  
  page.drawText(`Invoice Number: ${invoice.id}`, {
    x: width - margin - 150,
    y: yPosition,
    size: 10,
    font: helveticaFont,
    color: textColor,
  });
  
  yPosition -= 50;
  
  // Another border line
  page.drawLine({
    start: { x: margin, y: yPosition },
    end: { x: width - margin, y: yPosition },
    thickness: 1,
    color: lightGray,
  });
  yPosition -= 20;
  
  // Client info section
  page.drawText(`To: ${invoice.client?.name || 'Client Name'}`, {
    x: margin,
    y: yPosition,
    size: 10,
    font: helveticaFont,
    color: textColor,
  });
  
  // Client address (right side)
  if (invoice.client?.address) {
    const addressLines = invoice.client.address.split('\n');
    let addressY = yPosition;
    addressLines.forEach(line => {
      const lineWidth = helveticaFont.widthOfTextAtSize(line.trim(), 10);
      page.drawText(line.trim(), {
        x: width - margin - lineWidth,
        y: addressY,
        size: 10,
        font: helveticaFont,
        color: textColor,
      });
      addressY -= 12;
    });
  }
  
  yPosition -= 60;
  
  // Another border line
  page.drawLine({
    start: { x: margin, y: yPosition },
    end: { x: width - margin, y: yPosition },
    thickness: 1,
    color: lightGray,
  });
  yPosition -= 40;
  
  // Table headers with border
  page.drawLine({
    start: { x: margin, y: yPosition },
    end: { x: width - margin, y: yPosition },
    thickness: 1,
    color: lightGray,
  });
  yPosition -= 15;
  
  page.drawText('Item Description', {
    x: margin,
    y: yPosition,
    size: 12,
    font: helveticaBoldFont,
    color: textColor,
  });
  
  page.drawText('Price', {
    x: width - margin - 200,
    y: yPosition,
    size: 12,
    font: helveticaBoldFont,
    color: textColor,
  });
  
  page.drawText('QTY', {
    x: width - margin - 120,
    y: yPosition,
    size: 12,
    font: helveticaBoldFont,
    color: textColor,
  });
  
  page.drawText('Amount', {
    x: width - margin - 60,
    y: yPosition,
    size: 12,
    font: helveticaBoldFont,
    color: textColor,
  });
  
  yPosition -= 15;
  page.drawLine({
    start: { x: margin, y: yPosition },
    end: { x: width - margin, y: yPosition },
    thickness: 1,
    color: lightGray,
  });
  yPosition -= 20;
  
  // Table content
  if (invoice.items && invoice.items.length > 0) {
    invoice.items.forEach((item, index) => {
      page.drawText(item.description, {
        x: margin,
        y: yPosition,
        size: 11,
        font: helveticaFont,
        color: textColor,
      });
      
      const priceText = new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
      }).format(item.price);
      
      page.drawText(priceText, {
        x: width - margin - 200,
        y: yPosition,
        size: 11,
        font: helveticaFont,
        color: textColor,
      });
      
      page.drawText(item.quantity.toString(), {
        x: width - margin - 120,
        y: yPosition,
        size: 11,
        font: helveticaFont,
        color: textColor,
      });
      
      const amountText = new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
      }).format(item.price * item.quantity);
      
      page.drawText(amountText, {
        x: width - margin - 60,
        y: yPosition,
        size: 11,
        font: helveticaFont,
        color: textColor,
      });
      
      yPosition -= 25;
      
      // Draw light border after each item
      page.drawLine({
        start: { x: margin, y: yPosition + 5 },
        end: { x: width - margin, y: yPosition + 5 },
        thickness: 0.5,
        color: rgb(0.9, 0.9, 0.9),
      });
    });
  }
  
  yPosition -= 40;
  
  // Totals section (right aligned)
  const totalsX = width - margin - 200;
  
  if (invoice.subtotal !== undefined) {
    // Draw border line above totals
    page.drawLine({
      start: { x: totalsX, y: yPosition + 10 },
      end: { x: width - margin, y: yPosition + 10 },
      thickness: 1,
      color: lightGray,
    });
    
    page.drawText('Subtotal :', {
      x: totalsX,
      y: yPosition,
      size: 11,
      font: helveticaFont,
      color: textColor,
    });
    
    const subtotalText = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(invoice.subtotal);
    
    page.drawText(subtotalText, {
      x: width - margin - 80,
      y: yPosition,
      size: 11,
      font: helveticaFont,
      color: textColor,
    });
    yPosition -= 20;
    
    page.drawText(`Tax (${invoice.taxRate || 9}%) :`, {
      x: totalsX,
      y: yPosition,
      size: 11,
      font: helveticaFont,
      color: textColor,
    });
    
    const taxText = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(invoice.taxAmount || 0);
    
    page.drawText(taxText, {
      x: width - margin - 80,
      y: yPosition,
      size: 11,
      font: helveticaFont,
      color: textColor,
    });
    yPosition -= 30;
    
    // Draw border line above total
    page.drawLine({
      start: { x: totalsX, y: yPosition + 10 },
      end: { x: width - margin, y: yPosition + 10 },
      thickness: 1,
      color: lightGray,
    });
    
    page.drawText('Total Due :', {
      x: totalsX,
      y: yPosition,
      size: 14,
      font: helveticaBoldFont,
      color: textColor,
    });
    
    const totalText = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(invoice.amount);
    
    page.drawText(totalText, {
      x: width - margin - 80,
      y: yPosition,
      size: 14,
      font: helveticaBoldFont,
      color: textColor,
    });
  }
  
  yPosition -= 40;
  
  // Add Stripe payment link if available
  if (invoice.stripePaymentLink) {
    yPosition -= 80;
    
    // Payment section background
    page.drawRectangle({
      x: margin,
      y: yPosition - 50,
      width: width - 2 * margin,
      height: 50,
      color: rgb(0.95, 0.97, 1), // Light blue background
    });
    
    // Payment text
    page.drawText('Pay Online:', {
      x: margin + 20,
      y: yPosition - 20,
      size: 12,
      font: helveticaBoldFont,
      color: textColor,
    });
    
    // Add the payment link URL (will be clickable when PDF viewer supports it)
    page.drawText(invoice.stripePaymentLink, {
      x: margin + 20,
      y: yPosition - 35,
      size: 10,
      font: helveticaFont,
      color: primaryBlue,
    });
  }
  
  return pdfDoc;
}

function wrapText(text: string, maxLength: number): string[] {
  const words = text.split(' ');
  const lines: string[] = [];
  let currentLine = '';
  
  words.forEach(word => {
    if ((currentLine + word).length <= maxLength) {
      currentLine += (currentLine ? ' ' : '') + word;
    } else {
      if (currentLine) lines.push(currentLine);
      currentLine = word;
    }
  });
  
  if (currentLine) lines.push(currentLine);
  return lines;
}

export async function downloadInvoicePDF(invoice: InvoiceData, companyInfo?: CompanyInfo) {
  try {
    const pdfDoc = await generateInvoicePDF(invoice, companyInfo);
    const pdfBytes = await pdfDoc.save();
    
    const blob = new Blob([pdfBytes], { type: 'application/pdf' });
    saveAs(blob, `invoice-${invoice.id}.pdf`);
  } catch (error) {
    console.error('Error generating PDF:', error);
    throw new Error('Failed to generate PDF invoice');
  }
}