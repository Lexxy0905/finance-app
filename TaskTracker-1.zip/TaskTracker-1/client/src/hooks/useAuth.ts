import { useState, useEffect } from "react";
import { getAuthToken } from "@/lib/authHelpers";

export function useAuth() {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const authToken = getAuthToken();
        
        if (!authToken) {
          console.log("No auth token found - user not logged in");
          setUser(null);
          return;
        }
        
        const response = await fetch('https://x8ki-letl-twmt.n7.xano.io/api:CUU7m57L/auth/me', {
          headers: {
            'Authorization': `Bearer ${authToken}`,
            'Content-Type': 'application/json'
          }
        });
        
        if (response.ok) {
          const userData = await response.json();
          setUser(userData);
          localStorage.setItem("userData", JSON.stringify(userData));
        } else {
          console.log("Failed to fetch user data");
          setUser(null);
        }
      } catch (error) {
        console.error("Error fetching user:", error);
        setUser(null);
      } finally {
        setIsLoading(false);
      }
    };

    fetchUser();
  }, []);

  const logout = () => {
    localStorage.removeItem("userData");
    setUser(null);
    window.location.reload();
  };

  return {
    user,
    isLoading,
    isAuthenticated: !!user,
    logout,
  };
}
