import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import Dashboard from "@/components/Dashboard";
import Landing from "@/components/Landing";
import Layout from "@/components/Layout";
import ClientsPage from "@/components/ClientsPage";
import EmployeesPage from "@/components/EmployeesPage";
import InvoicesPage from "@/components/InvoicesPage";
import EmployeeInvoicesPage from "@/components/EmployeeInvoicesPage";
import ClientInvoicesPage from "@/components/ClientInvoicesPage";
import QuotationTemplate from "@/components/QuotationTemplate";
import NotFound from "@/pages/not-found";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  return (
    <Switch>
      {isLoading || !isAuthenticated ? (
        <>
          <Route path="/" component={Landing} />
          <Route path="/login" component={Landing} />
        </>
      ) : (
        <>
          <Route path="/" component={() => <Layout><Dashboard /></Layout>} />
          <Route path="/clients" component={() => <Layout><ClientsPage /></Layout>} />
          <Route path="/employees" component={() => <Layout><EmployeesPage /></Layout>} />
          <Route path="/invoices" component={() => <Layout><InvoicesPage /></Layout>} />
          <Route path="/employee-invoices" component={() => <Layout><EmployeeInvoicesPage /></Layout>} />
          <Route path="/client-invoices" component={() => <Layout><ClientInvoicesPage /></Layout>} />
          <Route path="/quotation-template" component={() => <Layout><QuotationTemplate /></Layout>} />
          <Route path="/login" component={Landing} />
        </>
      )}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
