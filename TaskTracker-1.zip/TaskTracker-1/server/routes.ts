import type { Express } from "express";
import { createServer, type Server } from "http";
import Stripe from "stripe";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertClientSchema, insertEmployeeSchema, insertInvoiceSchema } from "@shared/schema";
import { fromZodError } from "zod-validation-error";
import { sendEmail } from "./emailService";
import { generateQuotationPDF } from "./pdfService";

let stripe: Stripe | null = null;

if (process.env.STRIPE_SECRET_KEY) {
  stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
    apiVersion: "2025-05-28.basil",
  });
} else {
  console.warn('STRIPE_SECRET_KEY not provided - Stripe functionality will be disabled');
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.post('/api/logout', (req, res) => {
    req.logout((err) => {
      if (err) {
        console.error("Logout error:", err);
        return res.status(500).json({ message: "Logout failed" });
      }
      req.session.destroy((err) => {
        if (err) {
          console.error("Session destroy error:", err);
          return res.status(500).json({ message: "Session cleanup failed" });
        }
        res.json({ message: "Logged out successfully" });
      });
    });
  });

  // Client routes
  app.get("/api/clients", async (req, res) => {
    try {
      const clients = await storage.getClients();
      res.json(clients);
    } catch (error) {
      console.error("Error fetching clients:", error);
      res.status(500).json({ message: "Failed to fetch clients" });
    }
  });

  app.get("/api/clients/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const client = await storage.getClient(id);
      if (!client) {
        return res.status(404).json({ message: "Client not found" });
      }
      res.json(client);
    } catch (error) {
      console.error("Error fetching client:", error);
      res.status(500).json({ message: "Failed to fetch client" });
    }
  });

  app.post("/api/clients", isAuthenticated, async (req, res) => {
    try {
      const result = insertClientSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: fromZodError(result.error).toString() 
        });
      }
      const client = await storage.createClient(result.data);
      res.status(201).json(client);
    } catch (error) {
      console.error("Error creating client:", error);
      res.status(500).json({ message: "Failed to create client" });
    }
  });

  app.put("/api/clients/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const result = insertClientSchema.partial().safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: fromZodError(result.error).toString() 
        });
      }
      const client = await storage.updateClient(id, result.data);
      if (!client) {
        return res.status(404).json({ message: "Client not found" });
      }
      res.json(client);
    } catch (error) {
      console.error("Error updating client:", error);
      res.status(500).json({ message: "Failed to update client" });
    }
  });

  app.delete("/api/clients/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteClient(id);
      if (!success) {
        return res.status(404).json({ message: "Client not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting client:", error);
      res.status(500).json({ message: "Failed to delete client" });
    }
  });

  // Employee routes
  app.get("/api/employees", async (req, res) => {
    try {
      const employees = await storage.getEmployees();
      res.json(employees);
    } catch (error) {
      console.error("Error fetching employees:", error);
      res.status(500).json({ message: "Failed to fetch employees" });
    }
  });

  app.get("/api/employees/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const employee = await storage.getEmployee(id);
      if (!employee) {
        return res.status(404).json({ message: "Employee not found" });
      }
      res.json(employee);
    } catch (error) {
      console.error("Error fetching employee:", error);
      res.status(500).json({ message: "Failed to fetch employee" });
    }
  });

  app.post("/api/employees", isAuthenticated, async (req, res) => {
    try {
      const result = insertEmployeeSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: fromZodError(result.error).toString() 
        });
      }
      const employee = await storage.createEmployee(result.data);
      res.status(201).json(employee);
    } catch (error) {
      console.error("Error creating employee:", error);
      res.status(500).json({ message: "Failed to create employee" });
    }
  });

  app.put("/api/employees/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const result = insertEmployeeSchema.partial().safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: fromZodError(result.error).toString() 
        });
      }
      const employee = await storage.updateEmployee(id, result.data);
      if (!employee) {
        return res.status(404).json({ message: "Employee not found" });
      }
      res.json(employee);
    } catch (error) {
      console.error("Error updating employee:", error);
      res.status(500).json({ message: "Failed to update employee" });
    }
  });

  app.delete("/api/employees/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteEmployee(id);
      if (!success) {
        return res.status(404).json({ message: "Employee not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting employee:", error);
      res.status(500).json({ message: "Failed to delete employee" });
    }
  });

  // Invoice routes
  app.get("/api/invoices", isAuthenticated, async (req, res) => {
    try {
      const { status, clientId, employeeId } = req.query;
      let invoices;

      if (status) {
        invoices = await storage.getInvoicesByStatus(status as string);
      } else if (clientId) {
        invoices = await storage.getInvoicesByClient(parseInt(clientId as string));
      } else if (employeeId) {
        invoices = await storage.getInvoicesByEmployee(parseInt(employeeId as string));
      } else {
        invoices = await storage.getInvoices();
      }

      res.json(invoices);
    } catch (error) {
      console.error("Error fetching invoices:", error);
      res.status(500).json({ message: "Failed to fetch invoices" });
    }
  });

  app.get("/api/invoices/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const invoice = await storage.getInvoice(id);
      if (!invoice) {
        return res.status(404).json({ message: "Invoice not found" });
      }
      res.json(invoice);
    } catch (error) {
      console.error("Error fetching invoice:", error);
      res.status(500).json({ message: "Failed to fetch invoice" });
    }
  });

  app.post("/api/invoices", isAuthenticated, async (req, res) => {
    try {
      const result = insertInvoiceSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: fromZodError(result.error).toString() 
        });
      }
      const invoice = await storage.createInvoice(result.data);
      res.status(201).json(invoice);
    } catch (error) {
      console.error("Error creating invoice:", error);
      res.status(500).json({ message: "Failed to create invoice" });
    }
  });

  app.put("/api/invoices/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const result = insertInvoiceSchema.partial().safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: fromZodError(result.error).toString() 
        });
      }
      const invoice = await storage.updateInvoice(id, result.data);
      if (!invoice) {
        return res.status(404).json({ message: "Invoice not found" });
      }
      res.json(invoice);
    } catch (error) {
      console.error("Error updating invoice:", error);
      res.status(500).json({ message: "Failed to update invoice" });
    }
  });

  app.delete("/api/invoices/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteInvoice(id);
      if (!success) {
        return res.status(404).json({ message: "Invoice not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting invoice:", error);
      res.status(500).json({ message: "Failed to delete invoice" });
    }
  });

  // Stripe payment routes
  app.post("/api/create-payment-intent", isAuthenticated, async (req, res) => {
    if (!stripe) {
      return res.status(503).json({ 
        message: "Payment processing is currently unavailable. Stripe integration not configured." 
      });
    }

    try {
      const { amount, invoiceId } = req.body;
      
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(parseFloat(amount) * 100), // Convert to cents
        currency: "usd",
        metadata: {
          invoiceId: invoiceId.toString(),
        },
      });

      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      console.error("Error creating payment intent:", error);
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });

  // Stripe webhook
  app.post("/api/stripe-webhook", async (req, res) => {
    if (!stripe) {
      return res.status(503).json({ message: "Stripe webhooks not configured" });
    }

    const sig = req.headers['stripe-signature'];
    let event;

    try {
      event = stripe.webhooks.constructEvent(
        req.body,
        sig as string,
        process.env.STRIPE_WEBHOOK_SECRET || "whsec_test_secret"
      );
    } catch (err: any) {
      console.error("Webhook signature verification failed:", err.message);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    // Handle the event
    if (event.type === 'payment_intent.succeeded') {
      const paymentIntent = event.data.object;
      const invoiceId = paymentIntent.metadata?.invoiceId;

      if (invoiceId) {
        try {
          await storage.updateInvoice(parseInt(invoiceId), {
            status: "paid",
          });
          console.log(`Invoice ${invoiceId} marked as paid`);
        } catch (error) {
          console.error(`Error updating invoice ${invoiceId}:`, error);
        }
      }
    }

    res.json({ received: true });
  });

  // Email sending endpoint
  app.post("/api/send-email", isAuthenticated, async (req, res) => {
    try {
      const { to, subject, html, text, attachments } = req.body;
      
      if (!to || !subject || (!html && !text)) {
        return res.status(400).json({ 
          message: "Missing required fields: to, subject, and html or text content" 
        });
      }

      const emailParams = {
        to,
        from: process.env.SENDGRID_FROM_EMAIL || "noreply@financeflow.com",
        subject,
        html,
        text,
        attachments
      };

      const success = await sendEmail(emailParams);
      
      if (success) {
        res.json({ message: "Email sent successfully" });
      } else {
        res.status(500).json({ message: "Failed to send email" });
      }
    } catch (error) {
      console.error("Error sending email:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Download quotation PDF endpoint
  app.get("/api/download-quotation-pdf/:invoiceNumber", async (req, res) => {
    try {
      const { invoiceNumber } = req.params;
      const clientId = req.query.client;
      
      if (!invoiceNumber || !clientId) {
        return res.status(400).json({ 
          message: "Missing required parameters: invoiceNumber and client" 
        });
      }

      // You would need to store the quotation data when the invoice is created
      // For now, return a simple response or generate a basic PDF
      const quotationData = {
        invoiceNumber,
        clientName: "Sample Client",
        clientAddress: "Sample Address",
        items: [{ description: "Sample Item", price: 100, quantity: 1 }],
        taxRate: 0,
        currentDate: new Date().toLocaleDateString(),
        validUntilDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString(),
        stripePaymentLink: "",
        notes: "Generated PDF for download"
      };

      const pdfBytes = await generateQuotationPDF(quotationData);
      
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="quotation-${invoiceNumber}.pdf"`);
      res.send(Buffer.from(pdfBytes));
    } catch (error) {
      console.error("Error generating PDF download:", error);
      res.status(500).json({ message: "Failed to generate PDF" });
    }
  });

  // Send quotation email with PDF attachment
  app.post("/api/send-quotation-email", async (req, res) => {
    try {
      const { quotationData, clientEmail } = req.body;
      
      if (!quotationData || !clientEmail) {
        return res.status(400).json({ 
          message: "Missing required fields: quotationData and clientEmail" 
        });
      }

      // Generate PDF
      const pdfBytes = await generateQuotationPDF(quotationData);
      const pdfBase64 = Buffer.from(pdfBytes).toString('base64');

      // Get project name from first item description or use a default
      const projectName = quotationData.items && quotationData.items.length > 0 
        ? quotationData.items[0].description 
        : "Project";

      // Prepare email content
      const subject = "New Invoice";
      const html = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <p>Hello ${quotationData.clientName},</p>
          <p>Invoice for ${projectName} is attached to this email.</p>
          ${quotationData.stripePaymentLink ? `
          <p>Click the button below to make payment:</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="${quotationData.stripePaymentLink}" 
               style="background-color: #007cba; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block; font-weight: bold;">
              Make Payment
            </a>
          </div>
          ` : '<p>Click the button below to make payment</p>'}
        </div>
      `;

      const emailParams = {
        to: clientEmail,
        from: "lexxy0905@gmail.com",
        subject,
        html,
        attachments: [{
          content: pdfBase64,
          filename: `quotation-${quotationData.invoiceNumber}.pdf`,
          type: 'application/pdf',
          disposition: 'attachment'
        }]
      };

      const success = await sendEmail(emailParams);
      
      if (success) {
        res.json({ message: "Quotation email sent successfully" });
      } else {
        res.status(500).json({ message: "Failed to send quotation email" });
      }
    } catch (error) {
      console.error("Error sending quotation email:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Dashboard stats
  app.get("/api/dashboard/stats", isAuthenticated, async (req, res) => {
    try {
      const clients = await storage.getClients();
      const employees = await storage.getEmployees();
      const invoices = await storage.getInvoices();
      
      const paidInvoices = invoices.filter(inv => inv.status === "paid");
      const unpaidInvoices = invoices.filter(inv => inv.status === "unpaid");
      
      const totalRevenue = paidInvoices.reduce((sum, inv) => sum + parseFloat(inv.amount), 0);
      const outstandingAmount = unpaidInvoices.reduce((sum, inv) => sum + parseFloat(inv.amount), 0);

      const stats = {
        totalRevenue: totalRevenue.toFixed(2),
        outstandingAmount: outstandingAmount.toFixed(2),
        totalClients: clients.length,
        totalEmployees: employees.length,
        unpaidInvoicesCount: unpaidInvoices.length,
        paidInvoicesCount: paidInvoices.length,
      };

      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // Income chart data
  app.get("/api/dashboard/income-chart", isAuthenticated, async (req, res) => {
    try {
      const { months = 6 } = req.query;
      const invoices = await storage.getInvoicesByStatus("paid");
      
      // Generate mock chart data for now - in real implementation, 
      // this would aggregate actual invoice data by month
      const chartData = [];
      const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      const currentDate = new Date();
      
      for (let i = parseInt(months as string) - 1; i >= 0; i--) {
        const date = new Date(currentDate.getFullYear(), currentDate.getMonth() - i, 1);
        const monthlyTotal = Math.random() * 50000 + 30000; // Mock data
        
        chartData.push({
          month: monthNames[date.getMonth()],
          income: Math.round(monthlyTotal),
        });
      }

      res.json(chartData);
    } catch (error) {
      console.error("Error fetching income chart data:", error);
      res.status(500).json({ message: "Failed to fetch income chart data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
