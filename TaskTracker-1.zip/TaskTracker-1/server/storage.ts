import {
  users,
  clients,
  employees,
  invoices,
  type User,
  type UpsertUser,
  type Client,
  type InsertClient,
  type Employee,
  type InsertEmployee,
  type Invoice,
  type InsertInvoice,
} from "@shared/schema";

// Interface for storage operations
export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Client operations
  getClients(): Promise<Client[]>;
  getClient(id: number): Promise<Client | undefined>;
  createClient(client: InsertClient): Promise<Client>;
  updateClient(id: number, client: Partial<InsertClient>): Promise<Client | undefined>;
  deleteClient(id: number): Promise<boolean>;
  
  // Employee operations
  getEmployees(): Promise<Employee[]>;
  getEmployee(id: number): Promise<Employee | undefined>;
  createEmployee(employee: InsertEmployee): Promise<Employee>;
  updateEmployee(id: number, employee: Partial<InsertEmployee>): Promise<Employee | undefined>;
  deleteEmployee(id: number): Promise<boolean>;
  
  // Invoice operations
  getInvoices(): Promise<Invoice[]>;
  getInvoice(id: number): Promise<Invoice | undefined>;
  getInvoicesByClient(clientId: number): Promise<Invoice[]>;
  getInvoicesByEmployee(employeeId: number): Promise<Invoice[]>;
  getInvoicesByStatus(status: string): Promise<Invoice[]>;
  createInvoice(invoice: InsertInvoice): Promise<Invoice>;
  updateInvoice(id: number, invoice: Partial<InsertInvoice>): Promise<Invoice | undefined>;
  deleteInvoice(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private clients: Map<number, Client>;
  private employees: Map<number, Employee>;
  private invoices: Map<number, Invoice>;
  private clientIdCounter: number;
  private employeeIdCounter: number;
  private invoiceIdCounter: number;

  constructor() {
    this.users = new Map();
    this.clients = new Map();
    this.employees = new Map();
    this.invoices = new Map();
    this.clientIdCounter = 1;
    this.employeeIdCounter = 1;
    this.invoiceIdCounter = 1;
    
    // Initialize with some sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Sample clients
    const sampleClients = [
      { name: "Acme Corporation", email: "contact@acme.com", phone: "(555) 123-4567", address: "123 Business St, NYC" },
      { name: "Tech Solutions Ltd", email: "hello@techsolutions.com", phone: "(555) 987-6543", address: "456 Innovation Dr, SF" },
      { name: "Digital Marketing Co", email: "info@digitalmarketing.com", phone: "(555) 555-0123", address: "789 Creative Ave, LA" }
    ];

    // Sample employees
    const sampleEmployees = [
      { name: "Sarah Johnson", email: "sarah@company.com", role: "Developer", phone: "(555) 111-2222" },
      { name: "Mike Chen", email: "mike@company.com", role: "Designer", phone: "(555) 333-4444" },
      { name: "Emma Rodriguez", email: "emma@company.com", role: "Consultant", phone: "(555) 555-6666" }
    ];

    // Create sample data
    sampleClients.forEach(client => this.createClient(client));
    sampleEmployees.forEach(employee => this.createEmployee(employee));

    // Create sample invoices
    this.createInvoice({
      clientId: 1,
      employeeId: null,
      amount: "5200.00",
      dueDate: new Date("2024-12-15"),
      status: "unpaid",
      description: "Website development services"
    });

    this.createInvoice({
      clientId: null,
      employeeId: 1,
      amount: "4500.00",
      dueDate: new Date("2024-12-20"),
      status: "unpaid",
      description: "Consulting work - Q4"
    });
  }

  // User operations (required for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const user: User = {
      id: userData.id,
      email: userData.email || null,
      firstName: userData.firstName || null,
      lastName: userData.lastName || null,
      profileImageUrl: userData.profileImageUrl || null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.users.set(user.id, user);
    return user;
  }

  // Client operations
  async getClients(): Promise<Client[]> {
    return Array.from(this.clients.values());
  }

  async getClient(id: number): Promise<Client | undefined> {
    return this.clients.get(id);
  }

  async createClient(clientData: InsertClient): Promise<Client> {
    const id = this.clientIdCounter++;
    const client: Client = {
      id,
      name: clientData.name,
      email: clientData.email,
      phone: clientData.phone || null,
      address: clientData.address || null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.clients.set(id, client);
    return client;
  }

  async updateClient(id: number, clientData: Partial<InsertClient>): Promise<Client | undefined> {
    const existing = this.clients.get(id);
    if (!existing) return undefined;

    const updated: Client = {
      ...existing,
      ...clientData,
      updatedAt: new Date(),
    };
    this.clients.set(id, updated);
    return updated;
  }

  async deleteClient(id: number): Promise<boolean> {
    return this.clients.delete(id);
  }

  // Employee operations
  async getEmployees(): Promise<Employee[]> {
    return Array.from(this.employees.values());
  }

  async getEmployee(id: number): Promise<Employee | undefined> {
    return this.employees.get(id);
  }

  async createEmployee(employeeData: InsertEmployee): Promise<Employee> {
    const id = this.employeeIdCounter++;
    const employee: Employee = {
      id,
      name: employeeData.name,
      email: employeeData.email,
      role: employeeData.role,
      phone: employeeData.phone || null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.employees.set(id, employee);
    return employee;
  }

  async updateEmployee(id: number, employeeData: Partial<InsertEmployee>): Promise<Employee | undefined> {
    const existing = this.employees.get(id);
    if (!existing) return undefined;

    const updated: Employee = {
      ...existing,
      ...employeeData,
      updatedAt: new Date(),
    };
    this.employees.set(id, updated);
    return updated;
  }

  async deleteEmployee(id: number): Promise<boolean> {
    return this.employees.delete(id);
  }

  // Invoice operations
  async getInvoices(): Promise<Invoice[]> {
    return Array.from(this.invoices.values());
  }

  async getInvoice(id: number): Promise<Invoice | undefined> {
    return this.invoices.get(id);
  }

  async getInvoicesByClient(clientId: number): Promise<Invoice[]> {
    return Array.from(this.invoices.values()).filter(invoice => invoice.clientId === clientId);
  }

  async getInvoicesByEmployee(employeeId: number): Promise<Invoice[]> {
    return Array.from(this.invoices.values()).filter(invoice => invoice.employeeId === employeeId);
  }

  async getInvoicesByStatus(status: string): Promise<Invoice[]> {
    return Array.from(this.invoices.values()).filter(invoice => invoice.status === status);
  }

  async createInvoice(invoiceData: InsertInvoice): Promise<Invoice> {
    const id = this.invoiceIdCounter++;
    const invoice: Invoice = {
      id,
      clientId: invoiceData.clientId || null,
      employeeId: invoiceData.employeeId || null,
      amount: invoiceData.amount,
      dueDate: invoiceData.dueDate,
      status: invoiceData.status || "unpaid",
      description: invoiceData.description || null,
      invoicePdfUrl: null,
      stripePaymentIntentId: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.invoices.set(id, invoice);
    return invoice;
  }

  async updateInvoice(id: number, invoiceData: Partial<InsertInvoice>): Promise<Invoice | undefined> {
    const existing = this.invoices.get(id);
    if (!existing) return undefined;

    const updated: Invoice = {
      ...existing,
      ...invoiceData,
      updatedAt: new Date(),
    };
    this.invoices.set(id, updated);
    return updated;
  }

  async deleteInvoice(id: number): Promise<boolean> {
    return this.invoices.delete(id);
  }
}

export const storage = new MemStorage();
