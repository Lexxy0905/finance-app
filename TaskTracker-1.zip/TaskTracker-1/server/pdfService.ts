import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';

interface InvoiceItem {
  description: string;
  price: number;
  quantity: number;
}

interface QuotationData {
  clientName: string;
  clientAddress: string;
  items: InvoiceItem[];
  taxRate: number;
  stripePaymentLink?: string;
  notes?: string;
  invoiceNumber: string;
  currentDate: string;
  validUntilDate: string;
}

export async function generateQuotationPDF(data: QuotationData): Promise<Uint8Array> {
  const pdfDoc = await PDFDocument.create();
  const page = pdfDoc.addPage([595.276, 841.890]); // A4 size
  const { width, height } = page.getSize();
  
  // Load fonts
  const boldFont = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const regularFont = await pdfDoc.embedFont(StandardFonts.Helvetica);
  
  let yPosition = height - 60;
  
  // Header
  page.drawText('Finance Flow', {
    x: 50,
    y: yPosition,
    size: 20,
    font: boldFont,
    color: rgb(0.2, 0.4, 0.8),
  });
  
  page.drawText('Professional Invoicing', {
    x: 50,
    y: yPosition - 20,
    size: 10,
    font: regularFont,
    color: rgb(0.5, 0.5, 0.5),
  });
  
  // Quotation title
  page.drawText('QUOTATION', {
    x: width - 200,
    y: yPosition,
    size: 36,
    font: boldFont,
    color: rgb(0, 0, 0),
  });
  
  yPosition -= 80;
  
  // Invoice details
  page.drawText(`Date: ${data.currentDate}`, {
    x: 50,
    y: yPosition,
    size: 10,
    font: regularFont,
  });
  
  page.drawText(`Valid Until: ${data.validUntilDate}`, {
    x: 50,
    y: yPosition - 15,
    size: 10,
    font: regularFont,
  });
  
  page.drawText(`Invoice Number: ${data.invoiceNumber}`, {
    x: width - 200,
    y: yPosition,
    size: 10,
    font: regularFont,
  });
  
  yPosition -= 50;
  
  // Client information
  page.drawText(`To: ${data.clientName}`, {
    x: 50,
    y: yPosition,
    size: 12,
    font: boldFont,
  });
  
  // Client address (handle multi-line)
  const addressLines = data.clientAddress.split('\n');
  let addressY = yPosition - 20;
  addressLines.forEach(line => {
    page.drawText(line, {
      x: width - 200,
      y: addressY,
      size: 10,
      font: regularFont,
    });
    addressY -= 12;
  });
  
  yPosition -= 80;
  
  // Table header
  page.drawText('Item Description', {
    x: 50,
    y: yPosition,
    size: 10,
    font: boldFont,
  });
  
  page.drawText('Price', {
    x: 300,
    y: yPosition,
    size: 10,
    font: boldFont,
  });
  
  page.drawText('QTY', {
    x: 400,
    y: yPosition,
    size: 10,
    font: boldFont,
  });
  
  page.drawText('Amount', {
    x: 480,
    y: yPosition,
    size: 10,
    font: boldFont,
  });
  
  // Draw line under header
  page.drawLine({
    start: { x: 50, y: yPosition - 5 },
    end: { x: width - 50, y: yPosition - 5 },
    thickness: 1,
    color: rgb(0, 0, 0),
  });
  
  yPosition -= 25;
  
  // Items
  let subtotal = 0;
  data.items.forEach((item) => {
    const amount = item.price * item.quantity;
    subtotal += amount;
    
    page.drawText(item.description, {
      x: 50,
      y: yPosition,
      size: 10,
      font: regularFont,
    });
    
    page.drawText(`$${item.price.toFixed(2)}`, {
      x: 300,
      y: yPosition,
      size: 10,
      font: regularFont,
    });
    
    page.drawText(item.quantity.toString(), {
      x: 400,
      y: yPosition,
      size: 10,
      font: regularFont,
    });
    
    page.drawText(`$${amount.toFixed(2)}`, {
      x: 480,
      y: yPosition,
      size: 10,
      font: regularFont,
    });
    
    yPosition -= 20;
  });
  
  yPosition -= 20;
  
  // Totals
  const taxAmount = subtotal * (data.taxRate / 100);
  const total = subtotal + taxAmount;
  
  page.drawText(`Subtotal: $${subtotal.toFixed(2)}`, {
    x: 400,
    y: yPosition,
    size: 10,
    font: regularFont,
  });
  
  yPosition -= 15;
  
  page.drawText(`Tax (${data.taxRate}%): $${taxAmount.toFixed(2)}`, {
    x: 400,
    y: yPosition,
    size: 10,
    font: regularFont,
  });
  
  yPosition -= 15;
  
  page.drawText(`Total Due: $${total.toFixed(2)}`, {
    x: 400,
    y: yPosition,
    size: 12,
    font: boldFont,
  });
  
  // Payment link if provided
  if (data.stripePaymentLink) {
    yPosition -= 40;
    page.drawText('Pay Online:', {
      x: 50,
      y: yPosition,
      size: 10,
      font: boldFont,
    });
    
    page.drawText(data.stripePaymentLink, {
      x: 50,
      y: yPosition - 15,
      size: 9,
      font: regularFont,
      color: rgb(0.2, 0.4, 0.8),
    });
  }
  
  // Notes if provided
  if (data.notes) {
    yPosition -= 40;
    page.drawText('Notes:', {
      x: 50,
      y: yPosition,
      size: 10,
      font: boldFont,
    });
    
    const noteLines = data.notes.split('\n');
    let noteY = yPosition - 15;
    noteLines.forEach(line => {
      page.drawText(line, {
        x: 50,
        y: noteY,
        size: 9,
        font: regularFont,
      });
      noteY -= 12;
    });
  }
  
  return await pdfDoc.save();
}